package com.example.quizapp.ui.browse

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.quizapp.data.ExamRepository
import com.example.quizapp.model.Exam
import com.example.quizapp.model.ReviewItem
import com.example.quizapp.util.BrowseItem
import com.example.quizapp.util.BrowseStatus
import com.example.quizapp.util.getSubjectItems
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update

/** Mirrors the three `.result-filter-btn`s at the top of `renderBrowseSubject()`. */
enum class BrowseTab(val label: String) {
    ALL("همه تست‌ها"),
    WRONG("تست‌های غلط"),
    BLANK("تست‌های نزده")
}

enum class BrowseSortOrder { ASC, DESC }

data class BrowseSubjectUiState(
    val subject: String = "",
    val tab: BrowseTab = BrowseTab.ALL,
    val sortOrder: BrowseSortOrder = BrowseSortOrder.ASC,
    val sourceFilter: String? = null,
    val topicFilter: String? = null,
    val availableSources: List<String> = emptyList(),
    val availableTopics: List<String> = emptyList(),
    val items: List<BrowseItem> = emptyList(),
    val openItemKey: String? = null,
    val selecting: Boolean = false,
    val selectedKeys: Set<String> = emptySet(),
    val isAllSelected: Boolean = false
)

/** Everything that isn't derived straight from the exam list — mirrors the relevant `state.*` fields. */
private data class BrowseFilterState(
    val tab: BrowseTab = BrowseTab.ALL,
    val sortOrder: BrowseSortOrder = BrowseSortOrder.ASC,
    val sourceFilter: String? = null,
    val topicFilter: String? = null,
    val openItemKey: String? = null,
    val selecting: Boolean = false,
    val selectedKeys: Set<String> = emptySet()
)

/**
 * Kotlin/Compose equivalent of `renderBrowseSubject()` + `renderBrowseSubjectList()` +
 * `setBrowseTab()` + `toggleBrowseAnswer()` + the review-selection functions
 * (`startReviewSelection`/`toggleReviewItem`/`toggleSelectAllBrowse`/`createReviewQuiz`).
 */
class BrowseSubjectViewModel(
    private val repository: ExamRepository,
    private val subject: String
) : ViewModel() {

    private val filterState = MutableStateFlow(BrowseFilterState())

    val state: StateFlow<BrowseSubjectUiState> =
        combine(repository.exams, filterState) { exams, f -> buildState(exams, f) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), BrowseSubjectUiState(subject = subject))

    private fun buildState(exams: List<Exam>, f: BrowseFilterState): BrowseSubjectUiState {
        val allItems = getSubjectItems(exams, subject)
        val tabFiltered = when (f.tab) {
            BrowseTab.ALL -> allItems
            BrowseTab.WRONG -> allItems.filter { it.status == BrowseStatus.WRONG }
            BrowseTab.BLANK -> allItems.filter { it.status == BrowseStatus.BLANK }
        }
        val sources = tabFiltered.map { it.source }.distinct().sorted()
        val topics = tabFiltered.map { it.topic }.distinct().sorted()
        // mirrors `setBrowseTab()` dropping a filter that's no longer valid for the new tab
        val effectiveSource = f.sourceFilter?.takeIf { it in sources }
        val effectiveTopic = f.topicFilter?.takeIf { it in topics }

        var filtered = tabFiltered
        effectiveSource?.let { s -> filtered = filtered.filter { it.source == s } }
        effectiveTopic?.let { t -> filtered = filtered.filter { it.topic == t } }
        filtered = if (f.sortOrder == BrowseSortOrder.DESC) filtered.sortedByDescending { it.number }
        else filtered.sortedBy { it.number }

        return BrowseSubjectUiState(
            subject = subject,
            tab = f.tab,
            sortOrder = f.sortOrder,
            sourceFilter = effectiveSource,
            topicFilter = effectiveTopic,
            availableSources = sources,
            availableTopics = topics,
            items = filtered,
            openItemKey = f.openItemKey,
            selecting = f.selecting,
            selectedKeys = f.selectedKeys,
            isAllSelected = filtered.isNotEmpty() && filtered.all { it.itemKey in f.selectedKeys }
        )
    }

    /** Mirrors `setBrowseTab(tab)`. */
    fun setTab(tab: BrowseTab) = filterState.update { it.copy(tab = tab, openItemKey = null) }

    /** Mirrors `toggleBrowseAnswer(key)`. */
    fun toggleOpen(itemKey: String) = filterState.update {
        it.copy(openItemKey = if (it.openItemKey == itemKey) null else itemKey)
    }

    /** Mirrors `applyBrowseFilter()`. */
    fun applyFilter(sortOrder: BrowseSortOrder, sourceFilter: String?, topicFilter: String?) =
        filterState.update {
            it.copy(sortOrder = sortOrder, sourceFilter = sourceFilter, topicFilter = topicFilter, openItemKey = null)
        }

    /** Mirrors `startReviewSelection()`. */
    fun startSelection() = filterState.update { it.copy(selecting = true, selectedKeys = emptySet(), openItemKey = null) }

    /** Mirrors `cancelReviewSelection()`. */
    fun cancelSelection() = filterState.update { it.copy(selecting = false, selectedKeys = emptySet(), openItemKey = null) }

    /** Mirrors `toggleReviewItem(key, checked)`. */
    fun toggleItemSelected(itemKey: String) = filterState.update {
        it.copy(selectedKeys = if (itemKey in it.selectedKeys) it.selectedKeys - itemKey else it.selectedKeys + itemKey)
    }

    /** Mirrors `toggleSelectAllBrowse(checked)`. */
    fun toggleSelectAll(checked: Boolean) {
        val visibleKeys = state.value.items.map { it.itemKey }.toSet()
        filterState.update {
            it.copy(selectedKeys = if (checked) it.selectedKeys + visibleKeys else it.selectedKeys - visibleKeys)
        }
    }

    /**
     * Mirrors `createReviewQuiz()`: builds the selected [ReviewItem]s (sorted
     * by question number) from the *currently filtered* list, or `null` if
     * nothing is selected (caller shows "حداقل یک تست را انتخاب کنید").
     */
    fun buildSelectedReviewItems(): List<ReviewItem>? {
        val selected = state.value.items
            .filter { it.itemKey in state.value.selectedKeys }
            .sortedBy { it.number }
        if (selected.isEmpty()) return null
        return selected.map { x ->
            ReviewItem(
                itemKey = x.itemKey,
                baseExamId = x.baseExamId,
                n = x.number,
                user = x.userAnswer,
                key = x.correctAnswer,
                source = x.source,
                topic = x.topic
            )
        }
    }
}
