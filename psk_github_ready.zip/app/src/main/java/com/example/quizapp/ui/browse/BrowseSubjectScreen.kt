package com.example.quizapp.ui.browse

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.quizapp.model.ReviewItem
import com.example.quizapp.util.BrowseItem
import com.example.quizapp.util.BrowseStatus

/**
 * Kotlin/Compose equivalent of `renderBrowseSubject()` + `renderBrowseSubjectList()`
 * + `browseItemMarkup()` + the filter modal (`openBrowseFilterModal()`/`applyBrowseFilter()`).
 *
 * The filter/sort modal uses a plain [AlertDialog] with radio groups instead
 * of the original's custom segmented-pill layout — same idiomatic-Material3
 * simplification as the rest of the newer screens (Home/Result dialogs).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowseSubjectScreen(
    viewModel: BrowseSubjectViewModel,
    onBack: () -> Unit,
    onStartReviewQuiz: (List<ReviewItem>) -> Unit,
    onNoSelection: () -> Unit // mirrors showToast('حداقل یک تست را انتخاب کنید','warning')
) {
    val state by viewModel.state.collectAsState()
    var showFilterDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(state.subject) },
                navigationIcon = {
                    IconButton(onClick = { if (state.selecting) viewModel.cancelSelection() else onBack() }) {
                        if (state.selecting) Icon(Icons.Filled.Close, contentDescription = "انصراف")
                        else Icon(Icons.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                }
            )
        },
        bottomBar = {
            if (state.selecting) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            val items = viewModel.buildSelectedReviewItems()
                            if (items == null) onNoSelection() else onStartReviewQuiz(items)
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("شروع آزمون مرور") }
                    OutlinedButton(onClick = viewModel::cancelSelection, modifier = Modifier.weight(1f)) { Text("انصراف") }
                }
            } else {
                Box(modifier = Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) {
                    // mirrors `.review-fab` — "ایجاد آزمون مرور ＋"
                    Button(onClick = viewModel::startSelection) { Text("ایجاد آزمون مرور  ＋") }
                }
            }
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            // ---- browse-tab-row ----
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                BrowseTab.entries.forEach { tab ->
                    FilterChip(
                        selected = state.tab == tab,
                        onClick = { viewModel.setTab(tab) },
                        label = { Text(tab.label) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // ---- browse-toolbar-row ----
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(onClick = { showFilterDialog = true }) {
                    Icon(Icons.Filled.FilterList, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("فیلتر و ترتیب")
                }
                if (state.selecting) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("انتخاب همه", modifier = Modifier.padding(end = 6.dp))
                        Checkbox(checked = state.isAllSelected, onCheckedChange = viewModel::toggleSelectAll)
                        Text("${state.selectedKeys.size}", fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(Modifier.height(4.dp))

            // ---- browseListArea ----
            if (state.items.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("تستی برای نمایش وجود ندارد.", style = MaterialTheme.typography.bodyMedium)
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(state.items, key = { it.itemKey }) { item ->
                        BrowseItemCard(
                            item = item,
                            open = state.openItemKey == item.itemKey,
                            selecting = state.selecting,
                            checked = item.itemKey in state.selectedKeys,
                            onClick = {
                                if (state.selecting) viewModel.toggleItemSelected(item.itemKey)
                                else viewModel.toggleOpen(item.itemKey)
                            }
                        )
                    }
                }
            }
        }
    }

    if (showFilterDialog) {
        BrowseFilterDialog(
            state = state,
            onDismiss = { showFilterDialog = false },
            onApply = { sortOrder, source, topic ->
                viewModel.applyFilter(sortOrder, source, topic)
                showFilterDialog = false
            }
        )
    }
}

@Composable
private fun BrowseItemCard(
    item: BrowseItem,
    open: Boolean,
    selecting: Boolean,
    checked: Boolean,
    onClick: () -> Unit
) {
    val (bg, border) = when (item.status) {
        BrowseStatus.WRONG -> Color(0xFF38090D) to Color(0xFF7F1D1D)
        BrowseStatus.BLANK -> Color(0xFF192635) to Color(0xFF34485F)
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(bg)
            .border(1.dp, border, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(12.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            if (selecting) {
                Checkbox(checked = checked, onCheckedChange = { onClick() })
                Spacer(Modifier.width(4.dp))
            }
            Column(modifier = Modifier.weight(1f)) {
                Row {
                    Text("${item.source} · ${item.topic}", color = Color.White, style = MaterialTheme.typography.bodySmall)
                    if (item.reviewWrongCount > 0) {
                        Spacer(Modifier.width(6.dp))
                        Text("★", color = Color(0xFFEAB308))
                    }
                }
                Text("تست ${item.number}", color = Color.White, fontWeight = FontWeight.Black)
            }
        }
        if (open) {
            Spacer(Modifier.height(8.dp))
            Column {
                Text("جواب شما: ${item.userAnswer ?: "—"}", color = Color.White, style = MaterialTheme.typography.bodySmall)
                Text("گزینه صحیح: ${item.correctAnswer ?: "—"}", color = Color.White, style = MaterialTheme.typography.bodySmall)
                Text("مبحث: ${item.topic}", color = Color.White, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun BrowseFilterDialog(
    state: BrowseSubjectUiState,
    onDismiss: () -> Unit,
    onApply: (BrowseSortOrder, String?, String?) -> Unit
) {
    var sortOrder by remember { mutableStateOf(state.sortOrder) }
    var sourceFilter by remember { mutableStateOf(state.sourceFilter) }
    var topicFilter by remember { mutableStateOf(state.topicFilter) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("فیلتر و ترتیب") },
        text = {
            Column {
                Text("ترتیب شماره تست", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                RadioRow("کوچک به بزرگ", sortOrder == BrowseSortOrder.ASC) { sortOrder = BrowseSortOrder.ASC }
                RadioRow("بزرگ به کوچک", sortOrder == BrowseSortOrder.DESC) { sortOrder = BrowseSortOrder.DESC }

                Spacer(Modifier.height(12.dp))
                Text("منبع", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                RadioRow("همه منابع", sourceFilter == null) { sourceFilter = null }
                state.availableSources.forEach { s -> RadioRow(s, sourceFilter == s) { sourceFilter = s } }

                Spacer(Modifier.height(12.dp))
                Text("مبحث", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                RadioRow("همه مباحث", topicFilter == null) { topicFilter = null }
                state.availableTopics.forEach { t -> RadioRow(t, topicFilter == t) { topicFilter = t } }
            }
        },
        confirmButton = { TextButton(onClick = { onApply(sortOrder, sourceFilter, topicFilter) }) { Text("اعمال فیلتر") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

@Composable
private fun RadioRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label)
    }
}
