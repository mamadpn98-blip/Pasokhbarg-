package com.example.quizapp.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.quizapp.ui.quiz.GroupSize
import com.example.quizapp.ui.quiz.SheetTheme

/**
 * Kotlin/Compose equivalent of `renderSettings()`. Group-size/theme pickers
 * use [FilterChip] rows instead of the original's radio "segment" control —
 * same idiomatic-Material3 simplification as Home/Browse/Result dialogs.
 *
 * File I/O for backup/restore needs an `Activity` (Storage Access
 * Framework), which doesn't exist in this project — [onExportBackup] and
 * [onPickImportFile] are the two hooks a future `MainActivity` would wire up
 * (write [SettingsViewModel.exportBackupJson]'s result to a
 * `CreateDocument`-picked file; read an `OpenDocument`-picked file's text and
 * pass it to [SettingsViewModel.stagePendingImport]). Everything else —
 * including the "⚠️ replace current data?" confirm dialog — is handled here.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onBack: () -> Unit,
    onExportBackup: (json: String) -> Unit,
    onPickImportFile: () -> Unit
) {
    val settings by viewModel.settings.collectAsState()
    val pendingImport by viewModel.pendingImportJson.collectAsState()
    val resultMessage by viewModel.resultMessage.collectAsState()

    var scoreCorrectText by remember(settings.scoreCorrect) { mutableStateOf(settings.scoreCorrect.toString()) }
    var scoreWrongText by remember(settings.scoreWrongPenalty) { mutableStateOf(settings.scoreWrongPenalty.toString()) }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(resultMessage) {
        resultMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.consumeResultMessage()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("تنظیمات") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "بازگشت") } }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(
            modifier = Modifier.padding(padding).fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // ---- تقسیم‌بندی پاسخ‌برگ ----
            Column {
                Text("تقسیم‌بندی پاسخ‌برگ", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GroupSize.entries.forEach { gs ->
                        FilterChip(selected = settings.groupSize == gs, onClick = { viewModel.setGroupSize(gs) }, label = { Text(gs.label) })
                    }
                }
            }

            // ---- تم پاسخبرگ ----
            Column {
                Text("تم پاسخبرگ", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SheetTheme.entries.forEach { theme ->
                        FilterChip(selected = settings.theme == theme, onClick = { viewModel.setTheme(theme) }, label = { Text(theme.label) })
                    }
                }
            }

            // ---- نحوه نمره‌گذاری ----
            Column {
                Text("🧮 نحوه نمره‌گذاری", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(4.dp))
                Text(
                    "امتیاز هر پاسخ صحیح و جریمه هر پاسخ غلط را مطابق دفترچه آزمون خود تنظیم کنید (پیش‌فرض کنکور: صحیح ۳، جریمه غلط ۱).",
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = scoreCorrectText,
                        onValueChange = { scoreCorrectText = it },
                        label = { Text("امتیاز صحیح") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = scoreWrongText,
                        onValueChange = { scoreWrongText = it },
                        label = { Text("جریمه غلط") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        val sc = scoreCorrectText.toIntOrNull()
                        val sw = scoreWrongText.toIntOrNull()
                        if (sc != null && sw != null) viewModel.setScoreCoefficients(sc, sw)
                    }
                ) { Text("ذخیره نمره‌گذاری") }
            }

            // ---- پشتیبان‌گیری و بازیابی ----
            Column {
                Text("💾 پشتیبان‌گیری و بازیابی", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(4.dp))
                Text("📥 فایل پشتیبان شامل همهٔ آزمون‌های شماست.", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { onExportBackup(viewModel.exportBackupJson()) }) { Text("⬇️ دانلود فایل پشتیبان") }
                    OutlinedButton(onClick = onPickImportFile) { Text("📂 بازیابی از فایل") }
                }
            }
        }
    }

    if (pendingImport != null) {
        AlertDialog(
            onDismissRequest = viewModel::cancelPendingImport,
            title = { Text("تأیید") },
            text = { Text("⚠️ آیا اطلاعات فعلی با فایل پشتیبان جایگزین شود؟") },
            confirmButton = {
                TextButton(onClick = viewModel::confirmPendingImport) {
                    Text("✅ جایگزینی", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = viewModel::cancelPendingImport) { Text("انصراف") } }
        )
    }
}
