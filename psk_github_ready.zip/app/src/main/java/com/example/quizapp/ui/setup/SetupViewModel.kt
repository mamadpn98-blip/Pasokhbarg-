package com.example.quizapp.ui.setup

import androidx.lifecycle.ViewModel
import com.example.quizapp.model.Exam
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class Parity(val label: String) {
    ALL("همه تست‌ها"),
    ODD("می‌خواهم تست‌های فرد را بزنم"),
    EVEN("می‌خواهم تست‌های زوج را بزنم")
}

/** Mirrors `state.wizardData`. */
data class WizardData(
    val subject: String = "",
    val topic: String = "",
    val source: String = "",
    val timed: Boolean = false,
    val durationMinutes: String = "40", // kept as string like the JS input value, parsed on validation
    val start: String = "",
    val end: String = "",
    val parity: Parity = Parity.ALL
)

/** The finished, validated result — equivalent to JS `state.draft` right before `renderQuiz`. */
data class NewExamDraft(
    val subject: String,
    val topic: String,
    val source: String,
    val timed: Boolean,
    val durationMinutes: Int?,
    val numbers: List<Int>
)

data class SetupUiState(
    val step: Int = 1, // 1..3
    val data: WizardData = WizardData(),
    val errorMessage: String? = null,
    val invalidFields: Set<String> = emptySet(),
    val liveCount: Int? = null // only meaningful on step 2
)

private const val MAX_RANGE = 200 // end-start must be <= this (201 questions max, matches JS)

class SetupViewModel(pastExams: List<Exam> = emptyList()) : ViewModel() {

    private val _state = MutableStateFlow(SetupUiState())
    val state: StateFlow<SetupUiState> = _state.asStateFlow()

    // mirrors `buildSuggestCache()` — one frequency-sorted list per field, built once from exam history
    private val suggestCache: Map<String, List<String>> = mapOf(
        "subject" to freqValues(pastExams) { it.subject },
        "topic" to freqValues(pastExams) { it.topic },
        "source" to freqValues(pastExams) { it.source }
    )

    /** Mirrors `freqValues(field)`: distinct past values for a field, most-used first. */
    private fun freqValues(exams: List<Exam>, selector: (Exam) -> String?): List<String> {
        val counts = LinkedHashMap<String, Int>()
        exams.forEach { e ->
            val v = selector(e)?.trim().orEmpty()
            if (v.isNotEmpty()) counts[v] = (counts[v] ?: 0) + 1
        }
        return counts.entries.sortedByDescending { it.value }.map { it.key }
    }

    /**
     * Mirrors `filterSuggestions(field,q)`: case-insensitive substring match
     * against the cached history, capped at 8 results (same cap as the
     * original suggestion panel).
     */
    fun suggestionsFor(field: String, query: String): List<String> {
        val q = query.trim().lowercase()
        return (suggestCache[field] ?: emptyList())
            .filter { q.isEmpty() || it.lowercase().contains(q) }
            .take(8)
    }

    fun updateSubject(v: String) = updateData { it.copy(subject = v) }
    fun updateTopic(v: String) = updateData { it.copy(topic = v) }
    fun updateSource(v: String) = updateData { it.copy(source = v) }
    fun updateDurationMinutes(v: String) = updateData { it.copy(durationMinutes = v) }
    fun updateStart(v: String) = updateData { it.copy(start = v.filter(Char::isDigit).take(4).let { d -> if (v.startsWith("-")) "-$d" else d }) }.also { recomputeLiveCount() }
    fun updateEnd(v: String) = updateData { it.copy(end = v.filter(Char::isDigit).take(4).let { d -> if (v.startsWith("-")) "-$d" else d }) }.also { recomputeLiveCount() }
    fun setParity(p: Parity) = updateData { it.copy(parity = p) }

    fun setTimed(checked: Boolean) {
        updateData { d ->
            d.copy(
                timed = checked,
                durationMinutes = if (checked && d.durationMinutes.isBlank()) "40" else d.durationMinutes
            )
        }
    }

    private fun updateData(transform: (WizardData) -> WizardData) {
        _state.update { it.copy(data = transform(it.data), errorMessage = null, invalidFields = emptySet()) }
    }

    private fun recomputeLiveCount() {
        val d = _state.value.data
        val start = d.start.toIntOrNull()
        val end = d.end.toIntOrNull()
        val count = if (start != null && end != null && end >= start) {
            buildNumbers(start, end, d.parity).size
        } else null
        _state.update { it.copy(liveCount = count) }
    }

    /** Mirrors JS `buildNumbers(start, end, parity)`. */
    private fun buildNumbers(start: Int, end: Int, parity: Parity): List<Int> {
        val result = mutableListOf<Int>()
        for (n in start..end) {
            when (parity) {
                Parity.ODD -> if (kotlin.math.abs(n) % 2 == 0) continue
                Parity.EVEN -> if (kotlin.math.abs(n) % 2 == 1) continue
                Parity.ALL -> {}
            }
            result.add(n)
        }
        return result
    }

    /** Mirrors `wizardNext()` — validates the current step then advances. */
    fun next() {
        val d = _state.value.data
        when (_state.value.step) {
            1 -> {
                if (d.subject.isBlank()) {
                    setError("لطفاً نام درس را وارد کنید.", setOf("subject"))
                    return
                }
                val minutes = d.durationMinutes.toIntOrNull()
                if (d.timed && (minutes == null || minutes < 1)) {
                    setError("زمان آزمون باید حداقل 1 دقیقه و به صورت عدد صحیح باشد.", setOf("durationMinutes"))
                    return
                }
            }
            2 -> {
                val rangeError = validateRange(d)
                if (rangeError != null) {
                    setError(rangeError.first, rangeError.second)
                    return
                }
            }
        }
        _state.update { it.copy(step = (it.step + 1).coerceAtMost(3), errorMessage = null, invalidFields = emptySet()) }
    }

    /** Mirrors going back a wizard step / `انصراف` on step 1 (caller handles navigating away). */
    fun back(): Boolean {
        val current = _state.value.step
        return if (current > 1) {
            _state.update { it.copy(step = current - 1, errorMessage = null, invalidFields = emptySet()) }
            true
        } else {
            false // caller should navigate back / cancel
        }
    }

    private fun validateRange(d: WizardData): Pair<String, Set<String>>? {
        val rawStart = d.start.trim()
        val rawEnd = d.end.trim()
        if (rawStart.isEmpty() || rawEnd.isEmpty()) {
            val fields = buildSet {
                if (rawStart.isEmpty()) add("start")
                if (rawEnd.isEmpty()) add("end")
            }
            return "لطفاً شماره شروع و پایان بازه تست را وارد کنید." to fields
        }
        val start = rawStart.toIntOrNull()
        val end = rawEnd.toIntOrNull()
        if (start == null || end == null) {
            return "شماره شروع و پایان باید عدد صحیح باشند." to setOf("start", "end")
        }
        if (start == 0) return "شماره تست نمی‌تواند از صفر شروع شود." to setOf("start")
        if (end < start) return "شماره تست آخر باید بزرگ‌تر یا مساوی شماره تست اول باشد." to setOf("end")
        if (end - start > MAX_RANGE) return "بازه تست نمی‌تواند بیشتر از 201 تست باشد." to setOf("end")
        return null
    }

    private fun setError(message: String, fields: Set<String>) {
        _state.update { it.copy(errorMessage = message, invalidFields = fields) }
    }

    /**
     * Mirrors `startQuiz()` — full re-validation across all steps, and on
     * success returns the numbers/timing needed to hand off to the quiz
     * screen. On failure, jumps back to the offending step and sets the error.
     */
    fun finish(): NewExamDraft? {
        val d = _state.value.data

        if (d.subject.isBlank()) {
            _state.update { it.copy(step = 1) }
            setError("لطفاً نام درس را وارد کنید.", setOf("subject"))
            return null
        }
        val rangeError = validateRange(d)
        if (rangeError != null) {
            _state.update { it.copy(step = 2) }
            setError(rangeError.first, rangeError.second)
            return null
        }
        val minutes = d.durationMinutes.toIntOrNull()
        if (d.timed && (minutes == null || minutes < 1)) {
            _state.update { it.copy(step = 1) }
            setError("زمان آزمون باید حداقل 1 دقیقه و به صورت عدد صحیح باشد.", setOf("durationMinutes"))
            return null
        }

        val start = d.start.trim().toInt()
        val end = d.end.trim().toInt()
        val numbers = buildNumbers(start, end, d.parity)
        if (numbers.isEmpty()) {
            setError("با این انتخاب، هیچ تستی در بازه باقی نمی‌ماند.", emptySet())
            return null
        }

        return NewExamDraft(
            subject = d.subject.trim(),
            topic = d.topic.trim(),
            source = d.source.trim(),
            timed = d.timed,
            durationMinutes = if (d.timed) minutes else null,
            numbers = numbers
        )
    }
}
