package com.example.quizapp

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.quizapp.data.AppContainer
import com.example.quizapp.model.Exam
import com.example.quizapp.ui.browse.BrowseListScreen
import com.example.quizapp.ui.browse.BrowseListViewModel
import com.example.quizapp.ui.browse.BrowseSubjectScreen
import com.example.quizapp.ui.browse.BrowseSubjectViewModel
import com.example.quizapp.ui.home.HomeScreen
import com.example.quizapp.ui.home.HomeViewModel
import com.example.quizapp.ui.key.KeyScreen
import com.example.quizapp.ui.key.KeyViewModel
import com.example.quizapp.ui.nav.ReviewSession
import com.example.quizapp.ui.quiz.QuizScreen
import com.example.quizapp.ui.quiz.QuizViewModel
import com.example.quizapp.ui.result.ResultScreen
import com.example.quizapp.ui.result.ResultViewModel
import com.example.quizapp.ui.review.ReviewKeyScreen
import com.example.quizapp.ui.review.ReviewKeyViewModel
import com.example.quizapp.ui.review.ReviewQuizScreen
import com.example.quizapp.ui.review.ReviewQuizViewModel
import com.example.quizapp.ui.review.ReviewResultScreen
import com.example.quizapp.ui.review.ReviewTestsListScreen
import com.example.quizapp.ui.review.ReviewTestsListViewModel
import com.example.quizapp.ui.setup.SetupScreen
import com.example.quizapp.ui.setup.SetupViewModel
import com.example.quizapp.ui.stats.StatsScreen
import com.example.quizapp.ui.stats.StatsViewModel
import com.example.quizapp.ui.settings.SettingsScreen
import com.example.quizapp.ui.settings.SettingsViewModel
import com.example.quizapp.util.ScoringSettings
import com.example.quizapp.util.applyResolvedKeys
import com.example.quizapp.util.calculateResult
import com.example.quizapp.util.finishReviewExam
import com.example.quizapp.util.writeResolvedKeysBackToBaseExams
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * The one file this whole project was missing: an `Activity` + `NavHost`
 * that actually wires all 13 screens together, mirroring the JS single-page
 * app's `state.page` switch (`render()`'s big if/else chain) as an honest
 * Navigation-Compose graph instead.
 *
 * There's no Hilt/Koin here — [AppContainer] is the entire DI story, created
 * once and handed down. Every route builds its screen's `ViewModel` inline
 * with [viewModelFactory] since none of them take a bare no-arg constructor.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val container = AppContainer(applicationContext)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    QuizNavHost(container)
                }
            }
        }
    }
}

/** Mirrors `resultRoute()`-style dispatch: a review exam's result opens the review layout, not the regular one. */
private fun resultRouteFor(exam: Exam): String =
    if (exam.isReview) "reviewResult/${exam.id}" else "result/${exam.id}"

private fun formatDateForFileName(): String =
    SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())

@Composable
private fun QuizNavHost(container: AppContainer) {
    val navController: NavHostController = rememberNavController()
    // survives recomposition/navigation but not process death — see ReviewSession's own doc comment
    val reviewSession = remember { ReviewSession() }

    NavHost(navController = navController, startDestination = "home") {

        composable("home") {
            val vm: HomeViewModel = viewModel(
                factory = viewModelFactory {
                    initializer {
                        HomeViewModel(
                            repository = container.examRepository,
                            streakCountProvider = { container.settingsRepository.settings.value.streakCount }
                        )
                    }
                }
            )
            HomeScreen(
                viewModel = vm,
                onCreateExam = { navController.navigate("setup") },
                onOpenResult = { examId ->
                    container.examRepository.getExam(examId)?.let { navController.navigate(resultRouteFor(it)) }
                },
                onResumeExam = { examId -> navController.navigate("quiz/$examId") },
                onNavigateToBrowse = { navController.navigate("browseList") },
                onNavigateToStats = { navController.navigate("stats") },
                onNavigateToSettings = { navController.navigate("settings") }
            )
        }

        composable("setup") {
            val vm: SetupViewModel = viewModel(
                factory = viewModelFactory { initializer { SetupViewModel(pastExams = container.examRepository.exams.value) } }
            )
            SetupScreen(
                viewModel = vm,
                onCancel = { navController.popBackStack() },
                onReady = { draft ->
                    // mirrors `startQuiz()` creating `state.draft`/`state.currentExamId` up front,
                    // so the exam already exists (inProgress=true) the moment the quiz screen opens
                    val exam = Exam(
                        subject = draft.subject,
                        topic = draft.topic,
                        source = draft.source,
                        numbers = draft.numbers,
                        inProgress = true,
                        timed = draft.timed,
                        durationMinutes = draft.durationMinutes
                    )
                    container.examRepository.addExam(exam)
                    navController.navigate("quiz/${exam.id}") { popUpTo("home") }
                }
            )
        }

        composable("quiz/{examId}") { backStackEntry ->
            val examId = backStackEntry.arguments?.getString("examId")
            val exam = examId?.let { container.examRepository.getExam(it) }
            if (exam == null) {
                navController.popBackStack()
            } else {
                val settings by container.settingsRepository.settings.collectAsState()
                val vm: QuizViewModel = viewModel(
                    key = examId,
                    factory = viewModelFactory {
                        initializer {
                            QuizViewModel(
                                numbers = exam.numbers,
                                isTimed = exam.timed,
                                durationMinutes = exam.durationMinutes ?: 0,
                                groupSize = settings.groupSize,
                                theme = settings.theme,
                                existingAnswers = exam.quizAnswers,
                                initialElapsedSeconds = (exam.elapsedTimeSeconds ?: 0L).toInt()
                            )
                        }
                    }
                )
                QuizScreen(
                    viewModel = vm,
                    onContinue = { answers ->
                        // mirrors `finishQuiz()`: stash elapsed time, move to the key screen
                        val elapsed = vm.elapsedSecondsForSave()
                        container.examRepository.updateExam(
                            exam.copy(quizAnswers = answers, elapsedTimeSeconds = elapsed.toLong())
                        )
                        navController.navigate("key/$examId")
                    },
                    onBack = { navController.popBackStack() }
                )
            }
        }

        composable("key/{examId}") { backStackEntry ->
            val examId = backStackEntry.arguments?.getString("examId")
            val exam = examId?.let { container.examRepository.getExam(it) }
            if (exam == null) {
                navController.popBackStack()
            } else {
                val settings by container.settingsRepository.settings.collectAsState()
                val vm: KeyViewModel = viewModel(
                    key = examId,
                    // mirrors `Object.keys(state.quizAnswers).map(Number)` — only answered
                    // questions need a key; unanswered ones are automatically "blank"
                    factory = viewModelFactory { initializer { KeyViewModel(numbersNeedingKey = exam.quizAnswers.keys.toList()) } }
                )
                KeyScreen(
                    viewModel = vm,
                    onFinish = { keyAnswers ->
                        // mirrors `finishKey()` -> `saveCurrentExam()` -> `goToResult(...)`
                        val scoring = ScoringSettings(settings.scoreCorrect, settings.scoreWrongPenalty)
                        val updated = exam.copy(
                            keyAnswers = keyAnswers,
                            inProgress = false,
                            finishedAt = System.currentTimeMillis()
                        )
                        val finished = updated.copy(result = calculateResult(updated, scoring))
                        container.examRepository.updateExam(finished)
                        container.settingsRepository.recordCompletionForStreak()
                        navController.navigate("result/$examId") { popUpTo("home") }
                    },
                    onBack = { navController.popBackStack() }
                )
            }
        }

        composable("result/{examId}") { backStackEntry ->
            val examId = backStackEntry.arguments?.getString("examId")
            val exam = examId?.let { container.examRepository.getExam(it) }
            if (exam == null) {
                navController.popBackStack()
            } else {
                val settings by container.settingsRepository.settings.collectAsState()
                val vm: ResultViewModel = viewModel(
                    key = examId,
                    factory = viewModelFactory {
                        initializer {
                            ResultViewModel(exam, ScoringSettings(settings.scoreCorrect, settings.scoreWrongPenalty))
                        }
                    }
                )
                ResultScreen(
                    viewModel = vm,
                    onBackToHome = { navController.popBackStack("home", inclusive = false) }
                )
            }
        }

        composable("browseList") {
            val vm: BrowseListViewModel = viewModel(factory = viewModelFactory { initializer { BrowseListViewModel(container.examRepository) } })
            BrowseListScreen(
                viewModel = vm,
                onBack = { navController.popBackStack() },
                onOpenSubject = { subject -> navController.navigate("browseSubject/${Uri.encode(subject)}") },
                onOpenReviewTests = { subject -> navController.navigate("reviewTests/${Uri.encode(subject)}") }
            )
        }

        composable("browseSubject/{subject}") { backStackEntry ->
            val subject = Uri.decode(backStackEntry.arguments?.getString("subject") ?: "")
            val vm: BrowseSubjectViewModel = viewModel(
                key = subject,
                factory = viewModelFactory { initializer { BrowseSubjectViewModel(container.examRepository, subject) } }
            )
            val context = LocalContext.current
            BrowseSubjectScreen(
                viewModel = vm,
                onBack = { navController.popBackStack() },
                onStartReviewQuiz = { items ->
                    reviewSession.pendingSubject = subject
                    reviewSession.pendingItems = items
                    navController.navigate("reviewQuiz")
                },
                onNoSelection = { Toast.makeText(context, "حداقل یک تست را انتخاب کنید", Toast.LENGTH_SHORT).show() }
            )
        }

        composable("reviewQuiz") {
            val items = reviewSession.pendingItems ?: emptyList()
            val subject = reviewSession.pendingSubject ?: ""
            val settings by container.settingsRepository.settings.collectAsState()
            val vm: ReviewQuizViewModel = viewModel(
                factory = viewModelFactory { initializer { ReviewQuizViewModel(items, settings.groupSize, settings.theme) } }
            )
            ReviewQuizScreen(
                viewModel = vm,
                onContinue = { answers ->
                    reviewSession.pendingQuizAnswers = answers
                    val missing = vm.itemsMissingKey()
                    if (missing.isNotEmpty()) {
                        reviewSession.pendingMissingItems = missing
                        navController.navigate("reviewKey")
                    } else {
                        val exam = finishReviewExam(subject, items, answers)
                        container.examRepository.addExam(exam)
                        container.settingsRepository.recordCompletionForStreak()
                        reviewSession.clear()
                        navController.navigate("reviewResult/${exam.id}") { popUpTo("browseList") }
                    }
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable("reviewKey") {
            val missingItems = reviewSession.pendingMissingItems ?: emptyList()
            val vm: ReviewKeyViewModel = viewModel(factory = viewModelFactory { initializer { ReviewKeyViewModel(missingItems) } })
            ReviewKeyScreen(
                viewModel = vm,
                onFinish = { keyAnswers ->
                    val items = reviewSession.pendingItems ?: emptyList()
                    val subject = reviewSession.pendingSubject ?: ""
                    val quizAnswers = reviewSession.pendingQuizAnswers ?: emptyMap()
                    val resolvedItems = applyResolvedKeys(items, keyAnswers)
                    // mirrors the base-exam write-back side effect inside `finishReviewKey()`
                    writeResolvedKeysBackToBaseExams(container.examRepository, missingItems, keyAnswers)
                    val exam = finishReviewExam(subject, resolvedItems, quizAnswers)
                    container.examRepository.addExam(exam)
                    container.settingsRepository.recordCompletionForStreak()
                    reviewSession.clear()
                    navController.navigate("reviewResult/${exam.id}") { popUpTo("browseList") }
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable("reviewResult/{examId}") { backStackEntry ->
            val examId = backStackEntry.arguments?.getString("examId")
            val exam = examId?.let { container.examRepository.getExam(it) }
            if (exam == null) {
                navController.popBackStack()
            } else {
                ReviewResultScreen(exam = exam, onBack = { navController.popBackStack("home", inclusive = false) })
            }
        }

        composable("reviewTests/{subject}") { backStackEntry ->
            val subject = Uri.decode(backStackEntry.arguments?.getString("subject") ?: "")
            val vm: ReviewTestsListViewModel = viewModel(
                key = subject,
                factory = viewModelFactory { initializer { ReviewTestsListViewModel(container.examRepository, subject) } }
            )
            ReviewTestsListScreen(
                viewModel = vm,
                onBack = { navController.popBackStack() },
                onOpenResult = { examId -> navController.navigate("reviewResult/$examId") }
            )
        }

        composable("stats") {
            val vm: StatsViewModel = viewModel(factory = viewModelFactory { initializer { StatsViewModel(container.examRepository) } })
            StatsScreen(
                viewModel = vm,
                onBack = { navController.popBackStack() },
                onOpenResult = { examId ->
                    container.examRepository.getExam(examId)?.let { navController.navigate(resultRouteFor(it)) }
                }
            )
        }

        composable("settings") {
            val vm: SettingsViewModel = viewModel(
                factory = viewModelFactory { initializer { SettingsViewModel(container.settingsRepository, container.examRepository) } }
            )
            val context = LocalContext.current
            var pendingExportJson by remember { mutableStateOf<String?>(null) }

            val createDocumentLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
                val json = pendingExportJson
                if (uri != null && json != null) {
                    context.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray()) }
                }
                pendingExportJson = null
            }
            val openDocumentLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                if (uri != null) {
                    val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    if (text != null) vm.stagePendingImport(text)
                }
            }

            SettingsScreen(
                viewModel = vm,
                onBack = { navController.popBackStack() },
                onExportBackup = { json ->
                    pendingExportJson = json
                    createDocumentLauncher.launch("quiz-backup-${formatDateForFileName()}.json")
                },
                onPickImportFile = { openDocumentLauncher.launch(arrayOf("application/json")) }
            )
        }
    }
}
