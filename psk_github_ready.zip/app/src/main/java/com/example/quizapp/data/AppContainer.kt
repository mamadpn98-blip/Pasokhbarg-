package com.example.quizapp.data

import android.content.Context

/**
 * Minimal manual dependency container — this project has no Hilt/Koin set
 * up, so [MainActivity][com.example.quizapp.MainActivity] creates one of
 * these (backed by `applicationContext`, so it survives configuration
 * changes) and passes it down to every `NavHost` route.
 */
class AppContainer(context: Context) {
    val examRepository: ExamRepository = PrefsExamRepository(context.applicationContext)
    val settingsRepository: SettingsRepository = PrefsSettingsRepository(context.applicationContext)
}
