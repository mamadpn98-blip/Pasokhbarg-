package com.example.quizapp.ui.result

import androidx.lifecycle.ViewModel
import com.example.quizapp.model.Exam
import com.example.quizapp.model.ExamResult
import com.example.quizapp.util.ScoringSettings
import com.example.quizapp.util.calculateResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Which of correct/wrong/blank a given question number falls into. */
enum class ResultStatus { CORRECT, WRONG, BLANK }

/** One row of `.result-cards-grid` — mirrors what `resultItem(e,n,cls)` renders. */
data class ResultCardUi(
    val number: Int,
    val userAnswer: Int?,
    val correctAnswer: Int?,
    val status: ResultStatus
)

data class ResultUiState(
    val subject: String = "",
    val topic: String = "",
    val source: String = "",
    val createdAtMillis: Long? = null,
    val totalCount: Int = 0,
    val result: ExamResult = ExamResult(),
    val isTimed: Boolean = false,
    val durationMinutes: Int? = null,
    val tab: ResultTab = ResultTab.ALL,
    val visibleItems: List<ResultCardUi> = emptyList(),
    // fires the confetti burst once, only when the exam scored >= 80% — mirrors
    // `if((e.result?.percent??0)>=80)fireConfetti()` in `goToResult()`.
    val shouldCelebrate: Boolean = false
)

/**
 * Kotlin/Compose equivalent of `renderResult()` + `resultContent()` +
 * `resultItem()` + `setResultTab()`.
 *
 * [exam] is expected to already be the *finished* record (post `finishKey()`
 * → `saveCurrentExam()` in the JS flow), i.e. `quizAnswers` and `keyAnswers`
 * are both populated. If [Exam.result] hasn't been computed yet, it's
 * calculated here exactly like the JS `let r=e.result||calculateResult(e)`.
 */
class ResultViewModel(
    exam: Exam,
    scoringSettings: ScoringSettings = ScoringSettings()
) : ViewModel() {

    private val result: ExamResult = exam.result ?: calculateResult(exam, scoringSettings)

    /** All rows for the "all" tab — filtered subsets are derived from this, never recomputed. */
    private val allItems: List<ResultCardUi> = exam.numbers.map { n ->
        val status = when (n) {
            in result.correctNumbers -> ResultStatus.CORRECT
            in result.wrongNumbers -> ResultStatus.WRONG
            else -> ResultStatus.BLANK
        }
        ResultCardUi(
            number = n,
            userAnswer = exam.quizAnswers[n],
            correctAnswer = exam.keyAnswers[n],
            status = status
        )
    }

    private val _state = MutableStateFlow(buildState(ResultTab.ALL))
    val state: StateFlow<ResultUiState> = _state.asStateFlow()

    private fun buildState(tab: ResultTab) = ResultUiState(
        subject = exam.subject ?: "آزمون",
        topic = exam.topic ?: "",
        source = exam.source ?: "",
        createdAtMillis = exam.createdAt,
        totalCount = exam.numbers.size,
        result = result,
        isTimed = exam.timed,
        durationMinutes = exam.durationMinutes,
        tab = tab,
        visibleItems = filterItems(tab),
        shouldCelebrate = (result.percent) >= 80.0
    )

    /** Mirrors `resultContent()`'s per-tab filtering of `e.numbers`. */
    private fun filterItems(tab: ResultTab): List<ResultCardUi> = when (tab) {
        ResultTab.ALL -> allItems
        ResultTab.CORRECT -> allItems.filter { it.status == ResultStatus.CORRECT }
        ResultTab.WRONG -> allItems.filter { it.status == ResultStatus.WRONG }
        ResultTab.BLANK -> allItems.filter { it.status == ResultStatus.BLANK }
    }

    /** Mirrors `setResultTab(tab)`. */
    fun setTab(tab: ResultTab) {
        if (tab == _state.value.tab) return
        _state.value = buildState(tab)
    }
}
