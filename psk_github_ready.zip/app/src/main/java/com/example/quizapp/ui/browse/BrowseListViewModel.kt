package com.example.quizapp.ui.browse

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.quizapp.data.ExamRepository
import com.example.quizapp.util.BrowseSubjectSummary
import com.example.quizapp.util.getBrowseSubjects
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

data class BrowseListUiState(val subjects: List<BrowseSubjectSummary> = emptyList())

/** Kotlin/Compose equivalent of `goBrowseList()` + `renderBrowseList()`. */
class BrowseListViewModel(repository: ExamRepository) : ViewModel() {
    val state: StateFlow<BrowseListUiState> = repository.exams
        .map { BrowseListUiState(subjects = getBrowseSubjects(it)) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), BrowseListUiState())
}
