package com.example.quizapp.data

import android.content.Context
import android.content.SharedPreferences
import com.example.quizapp.model.Exam
import com.google.gson.Gson
import com.google.gson.JsonParser
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Storage contract. Kept as an interface so this can later be swapped for a
 * Room-backed implementation without touching the ViewModel/UI layer.
 */
interface ExamRepository {
    val exams: StateFlow<List<Exam>>
    fun addExam(exam: Exam)
    fun updateExam(exam: Exam)
    fun deleteExam(id: String)
    fun getExam(id: String): Exam?

    /** Mirrors `backupToFile()`'s JSON payload: `{version:4, createdAt, exams}`. */
    fun exportBackupJson(): String

    /**
     * Mirrors `restoreFromFile()`: accepts either a bare `[...]` array or a
     * `{exams:[...]}` object, and *replaces* the whole exam list (not a
     * merge). Returns the restored count, or `null` if the JSON was invalid.
     */
    fun importBackupJson(json: String): Int?
}

/**
 * Simple SharedPreferences + Gson implementation — the closest equivalent to
 * the original app's `localStorage.setItem('exams', JSON.stringify(exams))`.
 *
 * This is fine for the exam counts this app deals with. If the list grows
 * large, swap this for Room (recommended long-term, but not required to get
 * the Home screen working).
 */
class PrefsExamRepository(context: Context) : ExamRepository {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("quiz_app_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    private val _exams = MutableStateFlow(loadFromDisk())
    override val exams: StateFlow<List<Exam>> = _exams.asStateFlow()

    private fun loadFromDisk(): List<Exam> {
        val json = prefs.getString(KEY_EXAMS, null) ?: return emptyList()
        val type = object : TypeToken<List<Exam>>() {}.type
        return try {
            gson.fromJson(json, type) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun persist(list: List<Exam>) {
        _exams.value = list
        prefs.edit().putString(KEY_EXAMS, gson.toJson(list)).apply()
    }

    override fun addExam(exam: Exam) {
        persist(listOf(exam) + _exams.value)
    }

    override fun updateExam(exam: Exam) {
        persist(_exams.value.map { if (it.id == exam.id) exam else it })
    }

    override fun deleteExam(id: String) {
        persist(_exams.value.filterNot { it.id == id })
    }

    override fun getExam(id: String): Exam? = _exams.value.find { it.id == id }

    override fun exportBackupJson(): String {
        val payload = mapOf(
            "version" to 4,
            "createdAt" to SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).format(Date()),
            "exams" to _exams.value
        )
        return gson.toJson(payload)
    }

    override fun importBackupJson(json: String): Int? = try {
        val root = JsonParser.parseString(json)
        val examsElement = when {
            root.isJsonArray -> root
            root.isJsonObject && root.asJsonObject.has("exams") -> root.asJsonObject.get("exams")
            else -> null
        }
        if (examsElement == null || !examsElement.isJsonArray) {
            null
        } else {
            val type = object : TypeToken<List<Exam>>() {}.type
            val list: List<Exam>? = gson.fromJson(examsElement, type)
            if (list == null) null else { persist(list); list.size }
        }
    } catch (e: Exception) {
        null
    }

    companion object {
        private const val KEY_EXAMS = "exams"
    }
}
