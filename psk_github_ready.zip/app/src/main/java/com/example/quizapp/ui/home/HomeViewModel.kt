package com.example.quizapp.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.quizapp.data.ExamRepository
import com.example.quizapp.model.Exam
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

enum class HomeSort(val label: String) {
    DATE_DESC("جدیدترین"),
    DATE_ASC("قدیمی‌ترین"),
    PERCENT_DESC("بیشترین درصد"),
    PERCENT_ASC("کمترین درصد"),
    SUBJECT_ASC("نام درس")
}

data class HomeUiState(
    val visibleExams: List<Exam> = emptyList(),
    val hasMore: Boolean = false,
    val remainingCount: Int = 0,
    val search: String = "",
    val sort: HomeSort = HomeSort.DATE_DESC,
    val streakCount: Int = 0,
    val completedCount: Int = 0,
    val weekAveragePercent: Double? = null,
    val overallAveragePercent: Int? = null,
    val hasAnyExamsAtAll: Boolean = false
)

private const val HOME_PAGE_SIZE = 30

class HomeViewModel(
    private val repository: ExamRepository,
    private val streakCountProvider: () -> Int = { 0 }
) : ViewModel() {

    private val search = MutableStateFlow("")
    private val sort = MutableStateFlow(HomeSort.DATE_DESC)
    private val visibleCount = MutableStateFlow(HOME_PAGE_SIZE)

    val uiState: StateFlow<HomeUiState> =
        combine(repository.exams, search, sort, visibleCount) { exams, q, sortMode, count ->
            buildUiState(exams, q, sortMode, count)
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = HomeUiState()
        )

    private fun buildUiState(
        exams: List<Exam>,
        q: String,
        sortMode: HomeSort,
        visibleCount: Int
    ): HomeUiState {
        // *** This is the fix from the JS bug: review exams never enter the home list. ***
        val filtered = getFilteredExams(exams, q, sortMode)
        val visible = filtered.take(visibleCount)

        val completed = exams.filter { !it.inProgress && !it.isReview }
        val weekAgo = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
        val recentWeek = completed.filter { it.createdAt >= weekAgo }
        val weekAvg = if (recentWeek.isEmpty()) null
            else recentWeek.map { it.result?.percent ?: 0.0 }.average()
        val overallAvg = if (completed.isEmpty()) null
            else completed.map { it.result?.percent ?: 0.0 }.average().let { Math.round(it).toInt() }

        return HomeUiState(
            visibleExams = visible,
            hasMore = filtered.size > visible.size,
            remainingCount = filtered.size - visible.size,
            search = q,
            sort = sortMode,
            streakCount = streakCountProvider(),
            completedCount = completed.size,
            weekAveragePercent = weekAvg,
            overallAveragePercent = overallAvg,
            hasAnyExamsAtAll = exams.isNotEmpty()
        )
    }

    /**
     * Kotlin equivalent of the JS `getFilteredExams()`.
     *
     * The original bug was here: the JS version did `exams.slice()` with no
     * `isReview` filter, so review quizzes leaked into the home list (and
     * deleting them from home deleted the same underlying record used by the
     * "آزمون‌های مرور" screen). We filter it out up front, once, so no future
     * call site can forget to do it.
     */
    private fun getFilteredExams(exams: List<Exam>, q: String, sortMode: HomeSort): List<Exam> {
        var list = exams.filterNot { it.isReview }

        val query = q.trim()
        if (query.isNotEmpty()) {
            list = list.filter { exam ->
                listOfNotNull(exam.subject, exam.topic, exam.source)
                    .any { it.contains(query, ignoreCase = true) }
            }
        }

        list = when (sortMode) {
            HomeSort.DATE_ASC -> list.sortedBy { it.createdAt }
            HomeSort.DATE_DESC -> list.sortedByDescending { it.createdAt }
            HomeSort.PERCENT_DESC -> list.sortedByDescending { it.result?.percent ?: 0.0 }
            HomeSort.PERCENT_ASC -> list.sortedBy { it.result?.percent ?: 0.0 }
            HomeSort.SUBJECT_ASC -> list.sortedBy { it.subject ?: "" }
        }
        return list
    }

    fun onSearchChanged(value: String) {
        search.value = value
        visibleCount.value = HOME_PAGE_SIZE
    }

    fun onSortChanged(value: HomeSort) {
        sort.value = value
        visibleCount.value = HOME_PAGE_SIZE
    }

    fun loadMore() {
        visibleCount.value += HOME_PAGE_SIZE
    }

    fun deleteExam(id: String) = repository.deleteExam(id)
    fun resumeExam(id: String): Exam? = repository.getExam(id)

    /** Mirrors `saveEditExam(id)`: subject/topic/source only, no other fields touched. */
    fun updateExamDetails(id: String, subject: String, topic: String, source: String) {
        val exam = repository.getExam(id) ?: return
        repository.updateExam(exam.copy(subject = subject, topic = topic, source = source))
    }

    /**
     * Mirrors the undo branch of `deleteExam()`: `exams.splice(idx,0,removed)`.
     * Simplification: the JS version reinserts at the exact original index;
     * here it's reinserted at the top (same as [ExamRepository.addExam]),
     * which is functionally equivalent almost all the time since the list is
     * sorted newest-first and a just-deleted exam was usually near the top.
     */
    fun restoreExam(exam: Exam) = repository.addExam(exam)
}
