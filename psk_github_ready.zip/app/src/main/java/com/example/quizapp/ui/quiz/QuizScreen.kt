package com.example.quizapp.ui.quiz

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.font.FontWeight
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.quizapp.util.formatTime
import com.example.quizapp.util.toPersianDigits

/**
 * Answer-sheet screen — Kotlin/Compose equivalent of `renderQuiz(false)` +
 * its `.quiz-page` / `.paper.quiz-mode` / `.questions.sheet-mode` CSS.
 *
 * Layout mirrors the original 1:1:
 *  - dark page background, floating timer chip (only if timed)
 *  - a "paper" card with page title, subtitle, and a count-badge pill
 *  - a colored answer sheet: grouped rows of 5/10, each row = number
 *    strip (themed) + four option buttons (1..4) laid out left-to-right
 *  - primary "ادامه" / "ذخیره و ادامه بعداً" / secondary "بازگشت" actions
 */
@Composable
fun QuizScreen(
    viewModel: QuizViewModel,
    onContinue: (answers: Map<Int, Int>) -> Unit,
    onSaveForLater: (answers: Map<Int, Int>) -> Unit,
    onBack: () -> Unit
) {
    val state by viewModel.state.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.setOnTimeExpired { onContinue(state.answers) }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(QuizPalette.pageBackground)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 12.dp)
        ) {
            // ---- topbar ----
            Row(
                modifier = Modifier.fillMaxWidth().height(48.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "پاسخبرگ تستی",
                    color = QuizPalette.titleColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                Spacer(Modifier.width(1.dp))
            }

            Spacer(Modifier.height(8.dp))

            // ---- paper card ----
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
                Column(
                    modifier = Modifier
                        .widthIn(max = 760.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(QuizPalette.paperBackground)
                        .border(1.dp, QuizPalette.paperBorder, RoundedCornerShape(24.dp))
                        .padding(20.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    // quiz-head
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "پاسخ‌برگ آزمون",
                                color = QuizPalette.titleColor,
                                fontWeight = FontWeight.Black,
                                fontSize = 22.sp
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "گزینه‌ای را که برای هر تست انتخاب کرده‌اید علامت بزنید.",
                                color = QuizPalette.subtitleColor,
                                fontSize = 13.sp
                            )
                        }
                        CountBadge(state.numbers.size)
                    }

                    Spacer(Modifier.height(16.dp))

                    if (state.numbers.isEmpty()) {
                        NoticeBox("هیچ تستی انتخاب نشده است؛ بنابراین تمام تست‌ها نزده محسوب خواهند شد.")
                    } else {
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            AnswerSheet(
                                numbers = state.numbers,
                                answers = state.answers,
                                groupSize = state.groupSize,
                                theme = state.theme,
                                onChoose = viewModel::choose
                            )
                        }
                    }

                    Spacer(Modifier.height(24.dp))

                    // actions
                    Button(
                        onClick = { onContinue(state.answers) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = QuizPalette.primary)
                    ) { Text("ادامه", fontWeight = FontWeight.Bold) }

                    Spacer(Modifier.height(10.dp))

                    OutlinedButton(
                        onClick = { onSaveForLater(state.answers) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, QuizPalette.btnSaveLaterBorder),
                        colors = ButtonDefaults.outlinedButtonColors(containerColor = QuizPalette.btnSaveLaterBg)
                    ) { Text("ذخیره و ادامه بعداً", color = QuizPalette.btnSaveLaterText, fontWeight = FontWeight.Bold) }

                    Spacer(Modifier.height(10.dp))

                    Button(
                        onClick = onBack,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = QuizPalette.btnSecondaryBg)
                    ) { Text("بازگشت به صفحه قبل", color = QuizPalette.btnSecondaryText, fontWeight = FontWeight.Bold) }
                }
            }
        }

        // ---- floating timer chip (position:fixed top:14px left:14px in the original) ----
        if (state.isTimed) {
            TimerChip(
                seconds = state.timerSeconds,
                warning = state.timerIsWarning,
                modifier = Modifier.align(Alignment.TopStart).padding(14.dp)
            )
        }
    }
}

@Composable
private fun CountBadge(count: Int) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(QuizPalette.countBadgeBg)
            .padding(horizontal = 11.dp, vertical = 7.dp)
    ) {
        Text("$count تست", color = QuizPalette.countBadgeText, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
private fun NoticeBox(text: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(QuizPalette.noticeBg)
            .border(1.dp, QuizPalette.noticeBorder, RoundedCornerShape(14.dp))
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Text(text, color = QuizPalette.noticeText, fontSize = 13.sp, lineHeight = 20.sp)
    }
}

@Composable
private fun TimerChip(seconds: Int, warning: Boolean, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (warning) QuizPalette.timerWarningBg else QuizPalette.timerBg)
            .border(1.dp, QuizPalette.timerBorder, RoundedCornerShape(14.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .widthIn(min = 92.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(formatTime(seconds), color = Color.White, fontWeight = FontWeight.Black)
    }
}

/**
 * The scantron-style sheet itself — grouped rows of [groupSize] questions,
 * a colored number strip on the left of each row, and four option buttons
 * per row. Mirrors `.questions.sheet-mode` + `.q-group` + `.q-row`.
 */
@Composable
private fun AnswerSheet(
    numbers: List<Int>,
    answers: Map<Int, Int>,
    groupSize: GroupSize,
    theme: SheetTheme,
    onChoose: (Int, Int) -> Unit
) {
    val groups = numbers.chunked(groupSize.size)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(theme.background)
            .border(1.dp, theme.border, RoundedCornerShape(14.dp))
    ) {
        groups.forEachIndexed { idx, group ->
            if (idx > 0) {
                // q-group-spacer: a divider line between groups of 5/10
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(20.dp)
                        .background(theme.numberStripBg.copy(alpha = 0f)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(2.dp)
                            .background(theme.groupDividerLine)
                    )
                }
            }
            Column {
                group.forEach { n ->
                    QuestionRow(
                        number = n,
                        selected = answers[n],
                        theme = theme,
                        onChoose = { o -> onChoose(n, o) }
                    )
                }
            }
        }
    }
}

@Composable
private fun QuestionRow(
    number: Int,
    selected: Int?,
    theme: SheetTheme,
    onChoose: (Int) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().height(46.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // colored number strip — consecutive rows with no gap read as one
        // continuous colored column, matching `.q-group::before`
        Box(
            modifier = Modifier
                .width(48.dp)
                .fillMaxHeight()
                .background(theme.numberStripBg),
            contentAlignment = Alignment.Center
        ) {
            Text(
                number.toPersianDigits(),
                color = theme.numberColor,
                fontSize = qNumSizeSp(number).sp,
                fontWeight = FontWeight(qNumWeight(number).coerceIn(1, 1000))
            )
        }
        Row(
            modifier = Modifier.weight(1f).padding(horizontal = 10.dp, vertical = 5.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            (1..4).forEach { option ->
                OptionButton(
                    option = option,
                    isSelected = selected == option,
                    theme = theme,
                    onClick = { onChoose(option) }
                )
            }
        }
    }
}

@Composable
private fun OptionButton(
    option: Int,
    isSelected: Boolean,
    theme: SheetTheme,
    onClick: () -> Unit
) {
    val bg = if (isSelected) QuizPalette.optSelectedBg else Color(0xFFF8FAFC)
    val textColor = if (isSelected) QuizPalette.optSelectedText else theme.optionTextColor
    val borderColor = if (isSelected) QuizPalette.optSelectedBg else theme.optionBorder

    Box(
        modifier = Modifier
            .width(56.dp)
            .height(38.dp)
            .clip(RoundedCornerShape(13.dp))
            .background(bg)
            .border(1.dp, borderColor, RoundedCornerShape(13.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(option.toPersianDigits(), color = textColor, fontWeight = FontWeight.Black)
    }
}
