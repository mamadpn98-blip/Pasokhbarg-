package com.example.quizapp.ui.review

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.quizapp.model.ReviewItem
import com.example.quizapp.ui.quiz.QuizPalette
import com.example.quizapp.ui.quiz.SheetTheme
import com.example.quizapp.ui.quiz.qNumSizeSp
import com.example.quizapp.ui.quiz.qNumWeight
import com.example.quizapp.util.toPersianDigits

/**
 * Kotlin/Compose equivalent of `renderReviewQuiz()`. Visually identical to
 * [com.example.quizapp.ui.quiz.QuizScreen] (reuses its public [QuizPalette]/
 * [SheetTheme]) minus the timer, since rows here are keyed by
 * [ReviewItem.itemKey] rather than a plain `Int`.
 */
@Composable
fun ReviewQuizScreen(
    viewModel: ReviewQuizViewModel,
    onContinue: (answers: Map<String, Int>) -> Unit,
    onBack: () -> Unit
) {
    val state by viewModel.state.collectAsState()

    Box(modifier = Modifier.fillMaxSize().background(QuizPalette.pageBackground)) {
        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 12.dp)) {
            Text(
                "پاسخبرگ تستی",
                color = QuizPalette.titleColor,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                modifier = Modifier.height(48.dp).wrapContentHeight(Alignment.CenterVertically)
            )
            Spacer(Modifier.height(8.dp))

            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
                Column(
                    modifier = Modifier
                        .widthIn(max = 760.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(QuizPalette.paperBackground)
                        .border(1.dp, QuizPalette.paperBorder, RoundedCornerShape(24.dp))
                        .padding(20.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("پاسخ‌برگ آزمون", color = QuizPalette.titleColor, fontWeight = FontWeight.Black, fontSize = 22.sp)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "گزینه‌ای را که برای هر تست انتخاب کرده‌اید علامت بزنید.",
                                color = QuizPalette.subtitleColor,
                                fontSize = 13.sp
                            )
                        }
                        CountBadge(state.items.size)
                    }

                    Spacer(Modifier.height(16.dp))

                    if (state.items.isEmpty()) {
                        NoticeBox("هیچ تستی انتخاب نشده است؛ بنابراین تمام تست‌ها نزده محسوب خواهند شد.")
                    } else {
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            ReviewAnswerSheet(
                                items = state.items,
                                answers = state.answers,
                                groupSize = state.groupSize.size,
                                theme = state.theme,
                                onChoose = viewModel::choose
                            )
                        }
                    }

                    Spacer(Modifier.height(24.dp))
                    Button(
                        onClick = { onContinue(state.answers) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = QuizPalette.primary)
                    ) { Text("ادامه", fontWeight = FontWeight.Bold) }

                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = onBack,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = QuizPalette.btnSecondaryBg)
                    ) { Text("بازگشت به صفحه قبل", color = QuizPalette.btnSecondaryText, fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
}

@Composable
private fun CountBadge(count: Int) {
    Box(
        modifier = Modifier.clip(RoundedCornerShape(999.dp)).background(QuizPalette.countBadgeBg)
            .padding(horizontal = 11.dp, vertical = 7.dp)
    ) {
        Text("$count تست", color = QuizPalette.countBadgeText, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
private fun NoticeBox(text: String) {
    Box(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(QuizPalette.noticeBg)
            .border(1.dp, QuizPalette.noticeBorder, RoundedCornerShape(14.dp)).padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Text(text, color = QuizPalette.noticeText, fontSize = 13.sp, lineHeight = 20.sp)
    }
}

@Composable
private fun ReviewAnswerSheet(
    items: List<ReviewItem>,
    answers: Map<String, Int>,
    groupSize: Int,
    theme: SheetTheme,
    onChoose: (String, Int) -> Unit
) {
    val groups = items.chunked(groupSize)
    Column(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(theme.background)
            .border(1.dp, theme.border, RoundedCornerShape(14.dp))
    ) {
        groups.forEachIndexed { idx, group ->
            if (idx > 0) {
                Box(modifier = Modifier.fillMaxWidth().height(20.dp), contentAlignment = Alignment.Center) {
                    Box(modifier = Modifier.fillMaxWidth().height(2.dp).background(theme.groupDividerLine))
                }
            }
            Column {
                group.forEach { item ->
                    ReviewQuestionRow(
                        item = item,
                        selected = answers[item.itemKey],
                        theme = theme,
                        onChoose = { o -> onChoose(item.itemKey, o) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ReviewQuestionRow(item: ReviewItem, selected: Int?, theme: SheetTheme, onChoose: (Int) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth().height(46.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier.width(48.dp).fillMaxHeight().background(theme.numberStripBg),
            contentAlignment = Alignment.Center
        ) {
            Text(
                item.n.toPersianDigits(),
                color = theme.numberColor,
                fontSize = qNumSizeSp(item.n).sp,
                fontWeight = FontWeight(qNumWeight(item.n).coerceIn(1, 1000))
            )
        }
        Row(
            modifier = Modifier.weight(1f).padding(horizontal = 10.dp, vertical = 5.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            (1..4).forEach { option ->
                ReviewOptionButton(option = option, isSelected = selected == option, theme = theme, onClick = { onChoose(option) })
            }
        }
    }
}

@Composable
private fun ReviewOptionButton(option: Int, isSelected: Boolean, theme: SheetTheme, onClick: () -> Unit) {
    val bg = if (isSelected) QuizPalette.optSelectedBg else Color(0xFFF8FAFC)
    val textColor = if (isSelected) QuizPalette.optSelectedText else theme.optionTextColor
    val borderColor = if (isSelected) QuizPalette.optSelectedBg else theme.optionBorder

    Box(
        modifier = Modifier.width(56.dp).height(38.dp).clip(RoundedCornerShape(13.dp)).background(bg)
            .border(1.dp, borderColor, RoundedCornerShape(13.dp)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(option.toPersianDigits(), color = textColor, fontWeight = FontWeight.Black)
    }
}
