package com.example.quizapp.ui.stats

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.quizapp.util.StatsChartPoint
import com.example.quizapp.util.StatsHighlight
import com.example.quizapp.util.StatsSubjectSummary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Kotlin/Compose equivalent of `renderStats()`. The percent-over-time line
 * chart is a hand-drawn [Canvas] (grid lines + polyline + dots), mirroring
 * the original's inline SVG.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatsScreen(
    viewModel: StatsViewModel,
    onBack: () -> Unit,
    onOpenResult: (String) -> Unit
) {
    val state by viewModel.state.collectAsState()
    var subjectMenuExpanded by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("آمار و نمودار پیشرفت") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "بازگشت") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.padding(padding).fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // ---- stats-toolbar: subject select ----
            Box {
                OutlinedButton(onClick = { subjectMenuExpanded = true }) {
                    Text((state.selectedSubject ?: "همه درس‌ها") + "  ⌄")
                }
                DropdownMenu(expanded = subjectMenuExpanded, onDismissRequest = { subjectMenuExpanded = false }) {
                    DropdownMenuItem(
                        text = { Text("همه درس‌ها") },
                        onClick = { viewModel.selectSubject(null); subjectMenuExpanded = false }
                    )
                    state.subjects.forEach { subject ->
                        DropdownMenuItem(
                            text = { Text(subject) },
                            onClick = { viewModel.selectSubject(subject); subjectMenuExpanded = false }
                        )
                    }
                }
            }

            // ---- stats-chart-card ----
            StatsCard {
                Text("روند درصد آزمون‌ها", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(10.dp))
                StatsChart(state.chartPoints)
                if (state.chartPoints.isNotEmpty()) {
                    Spacer(Modifier.height(4.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(formatDate(state.chartPoints.first().createdAt), style = MaterialTheme.typography.labelSmall)
                        Text("روند زمانی آزمون‌ها ←", style = MaterialTheme.typography.labelSmall)
                        Text(formatDate(state.chartPoints.last().createdAt), style = MaterialTheme.typography.labelSmall)
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "● درصد هر آزمون — آزمون‌های مرور در این نمودار نیستند",
                    style = MaterialTheme.typography.labelSmall,
                    color = StatsPalette.muted
                )
            }

            // ---- stats-mini-card: KPIs ----
            StatsCard {
                Text("خلاصه عملکرد", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatsKpiItem(state.averagePercent?.let { "${"%.1f".format(it)}٪" } ?: "—", "میانگین درصد", Modifier.weight(1f))
                    StatsKpiItem(state.bestPercent?.let { "${"%.1f".format(it)}٪" } ?: "—", "بهترین درصد", Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatsKpiItem("${state.totalQuestions}", "کل تست‌ها", Modifier.weight(1f))
                    StatsKpiItem("${state.totalCorrect}", "صحیح", Modifier.weight(1f))
                }
            }

            // ---- lower: subject grid OR per-subject highlights ----
            if (state.selectedSubject == null) {
                if (state.subjectCards.isEmpty()) {
                    Text("هنوز آزمون تکمیل‌شده‌ای برای تحلیل وجود ندارد.", style = MaterialTheme.typography.bodyMedium)
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        state.subjectCards.forEach { card -> StatsSubjectCard(card) { viewModel.selectSubject(card.subject) } }
                    }
                }
            } else {
                Text("جزئیات ${state.selectedSubject}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                if (state.highlights.isEmpty()) {
                    Text("برای این درس آزمون تکمیل‌شده‌ای وجود ندارد.", style = MaterialTheme.typography.bodyMedium)
                } else {
                    val rows = state.highlights.chunked(2)
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        rows.forEach { row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                row.forEach { h -> StatsHighlightCard(h, Modifier.weight(1f)) { onOpenResult(h.examId) } }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatsCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(StatsPalette.panelBackground)
            .border(1.dp, StatsPalette.panelBorder, RoundedCornerShape(18.dp))
            .padding(16.dp),
        content = content
    )
}

/** `.stats-chart-svg` — grid lines every 10%, a polyline of percentages, and a dot per exam. */
@Composable
private fun StatsChart(points: List<StatsChartPoint>) {
    val density = LocalDensity.current
    val gridColor = StatsPalette.gridLine
    val lineColor = StatsPalette.primary
    val labelPaint = remember {
        android.graphics.Paint().apply {
            color = android.graphics.Color.parseColor("#9AA9BA")
            textSize = with(density) { 11.sp.toPx() }
            textAlign = android.graphics.Paint.Align.RIGHT
            isAntiAlias = true
        }
    }

    Canvas(modifier = Modifier.fillMaxWidth().height(180.dp)) {
        val padLeft = 34.dp.toPx()
        val padRight = 8.dp.toPx()
        val padTop = 8.dp.toPx()
        val padBottom = 8.dp.toPx()
        val innerW = size.width - padLeft - padRight
        val innerH = size.height - padTop - padBottom

        var p = 0
        while (p <= 100) {
            val y = padTop + (100 - p) * innerH / 100f
            drawLine(color = gridColor, start = Offset(padLeft, y), end = Offset(size.width - padRight, y), strokeWidth = 1.dp.toPx())
            drawContext.canvas.nativeCanvas.drawText("$p٪", padLeft - 6.dp.toPx(), y + 4.dp.toPx(), labelPaint)
            p += 10
        }

        if (points.isEmpty()) {
            val y = padTop + innerH
            drawLine(color = lineColor, start = Offset(padLeft, y), end = Offset(size.width - padRight, y), strokeWidth = 3.dp.toPx())
        } else {
            val coords = points.map { pt ->
                val x = if (points.size <= 1) padLeft + innerW / 2f else padLeft + pt.index * innerW / (points.size - 1)
                val y = padTop + (100f - pt.percent.toFloat()) * innerH / 100f
                Offset(x, y)
            }
            val path = Path().apply { coords.forEachIndexed { i, c -> if (i == 0) moveTo(c.x, c.y) else lineTo(c.x, c.y) } }
            drawPath(path, color = lineColor, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            coords.forEach { c -> drawCircle(color = lineColor, radius = 4.5.dp.toPx(), center = c) }
        }
    }
}

@Composable
private fun StatsKpiItem(value: String, label: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(StatsPalette.surface3)
            .border(1.dp, StatsPalette.panelBorder, RoundedCornerShape(14.dp))
            .padding(vertical = 12.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, color = StatsPalette.text, fontWeight = FontWeight.Black, fontSize = 18.sp)
        Spacer(Modifier.height(4.dp))
        Text(label, color = StatsPalette.muted, fontSize = 11.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun StatsSubjectCard(card: StatsSubjectSummary, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(StatsPalette.panelBackground)
            .border(1.dp, StatsPalette.panelBorder, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(14.dp)
    ) {
        Text(card.subject, color = StatsPalette.text, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(
            "${card.examCount} آزمون · میانگین ${"%.1f".format(card.averagePercent)}٪",
            color = StatsPalette.muted,
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(
            progress = { (card.averagePercent.coerceIn(0.0, 100.0) / 100.0).toFloat() },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
        )
    }
}

@Composable
private fun StatsHighlightCard(h: StatsHighlight, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(StatsPalette.panelBackground)
            .border(1.dp, StatsPalette.panelBorder, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(12.dp)
    ) {
        Text(h.label, color = StatsPalette.muted, style = MaterialTheme.typography.labelSmall)
        Spacer(Modifier.height(4.dp))
        Text(h.title, color = StatsPalette.text, fontWeight = FontWeight.Bold, maxLines = 1)
        Spacer(Modifier.height(4.dp))
        Text(h.value, color = StatsPalette.primary, fontWeight = FontWeight.Black, fontSize = 16.sp)
        Spacer(Modifier.height(4.dp))
        Text("${formatDate(h.createdAt)} · ${h.questionCount} تست", color = StatsPalette.muted, style = MaterialTheme.typography.labelSmall)
    }
}

private fun formatDate(millis: Long): String = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(Date(millis))

private object StatsPalette {
    val panelBackground = Color(0xFF10161E)
    val panelBorder = Color(0xFF263241)
    val text = Color(0xFFF5F7FA)
    val muted = Color(0xFF9AA8B8)
    val surface3 = Color(0xFF1B2531)
    val primary = Color(0xFF4F8CFF)
    val gridLine = Color(0xFF2A3B50)
}
