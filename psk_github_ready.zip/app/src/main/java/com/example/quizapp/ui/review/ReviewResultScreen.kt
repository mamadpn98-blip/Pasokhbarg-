package com.example.quizapp.ui.review

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.quizapp.model.Exam
import com.example.quizapp.ui.result.ResultPalette
import com.example.quizapp.ui.result.ResultStatus
import com.example.quizapp.ui.result.cardBorder
import com.example.quizapp.ui.result.cardGradient

/**
 * Kotlin/Compose equivalent of `renderReviewResult()`. Reuses [ResultPalette]
 * (and its `cardGradient`/`cardBorder` extensions) so the answer cards look
 * identical to the regular result screen — no filter tabs here though, the
 * original always shows the full list, and the 4th stat is a literal "—"
 * (review exams don't have a percent — they're explicitly excluded from stats).
 */
@Composable
fun ReviewResultScreen(exam: Exam, onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("نتیجه آزمون مرور") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "بازگشت") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(ResultPalette.panelBackground)
                .border(1.dp, ResultPalette.panelBorder, RoundedCornerShape(22.dp))
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(exam.subject ?: "آزمون مرور", color = ResultPalette.text, fontWeight = FontWeight.Black, fontSize = 22.sp)
            Spacer(Modifier.height(4.dp))
            Text("${exam.items.size} تست · فقط برای مرور", color = ResultPalette.muted, fontSize = 13.sp)

            Spacer(Modifier.height(16.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ReviewStatItem("${exam.result?.correctCount ?: 0}", "صحیح", Modifier.weight(1f))
                ReviewStatItem("${exam.result?.wrongCount ?: 0}", "غلط", Modifier.weight(1f))
                ReviewStatItem("${exam.result?.blankCount ?: 0}", "نزده", Modifier.weight(1f))
                ReviewStatItem("—", "درصد آماری", Modifier.weight(1f))
            }

            Spacer(Modifier.height(16.dp))
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                exam.items.forEach { item ->
                    val rr = exam.reviewResults.find { it.itemKey == item.itemKey }
                    val answered = exam.reviewQuizAnswers[item.itemKey]
                    // mirrors `rr?.wrong?(e.quizAnswers?.[x.itemKey]?'wrong':'blank'):'correct'`
                    val status = when {
                        rr?.wrong != true -> ResultStatus.CORRECT
                        answered != null -> ResultStatus.WRONG
                        else -> ResultStatus.BLANK
                    }
                    ReviewResultCard(number = item.n, answer = answered, correct = item.key, status = status)
                }
            }
        }
    }
}

@Composable
private fun ReviewStatItem(value: String, label: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(ResultPalette.surface3)
            .border(1.dp, ResultPalette.panelBorder, RoundedCornerShape(16.dp))
            .padding(vertical = 14.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, color = ResultPalette.text, fontWeight = FontWeight.Black, fontSize = 20.sp)
        Spacer(Modifier.height(5.dp))
        Text(label, color = ResultPalette.muted, fontSize = 11.5.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun ReviewResultCard(number: Int, answer: Int?, correct: Int?, status: ResultStatus) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(ResultPalette.cardGradient(status))
            .border(1.dp, ResultPalette.cardBorder(status), RoundedCornerShape(10.dp))
            .padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("تست $number", color = ResultPalette.text, fontWeight = FontWeight.Black, fontSize = 15.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            Text("جواب: ${answer ?: "—"}", color = ResultPalette.text, fontSize = 12.5.sp)
            Text("صحیح: ${correct ?: "—"}", color = ResultPalette.text, fontSize = 12.5.sp)
        }
    }
}
