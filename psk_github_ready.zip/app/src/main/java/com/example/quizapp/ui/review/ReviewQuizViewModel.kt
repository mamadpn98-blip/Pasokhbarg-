package com.example.quizapp.ui.review

import androidx.lifecycle.ViewModel
import com.example.quizapp.model.ReviewItem
import com.example.quizapp.ui.quiz.GroupSize
import com.example.quizapp.ui.quiz.SheetTheme
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class ReviewQuizUiState(
    val items: List<ReviewItem> = emptyList(),
    val answers: Map<String, Int> = emptyMap(),
    val groupSize: GroupSize = GroupSize.FIVE,
    val theme: SheetTheme = SheetTheme.RED
)

/**
 * Kotlin/Compose equivalent of `renderReviewQuiz()` + `chooseReviewAnswer()`.
 * Same "sheet" UI as the regular quiz screen but rows are keyed by
 * [ReviewItem.itemKey] (a string) instead of a plain question number, and
 * there's no timer (the original review quiz never sets one).
 */
class ReviewQuizViewModel(
    items: List<ReviewItem>,
    groupSize: GroupSize = GroupSize.FIVE,
    theme: SheetTheme = SheetTheme.RED
) : ViewModel() {

    private val _state = MutableStateFlow(ReviewQuizUiState(items = items, groupSize = groupSize, theme = theme))
    val state: StateFlow<ReviewQuizUiState> = _state.asStateFlow()

    /** Mirrors `chooseReviewAnswer(key,o)` — tapping the already-selected option clears it. */
    fun choose(itemKey: String, option: Int) {
        _state.update { s ->
            val current = s.answers.toMutableMap()
            if (current[itemKey] == option) current.remove(itemKey) else current[itemKey] = option
            s.copy(answers = current)
        }
    }

    /** Mirrors `continueReviewQuiz()`'s check: items with no key at all need the review-key screen next. */
    fun itemsMissingKey(): List<ReviewItem> = _state.value.items.filter { it.key == null }
}
