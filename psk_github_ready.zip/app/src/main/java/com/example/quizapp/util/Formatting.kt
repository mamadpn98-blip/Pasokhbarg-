package com.example.quizapp.util

private val persianDigits = charArrayOf('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹')

/** Mirrors JS `toPersianDigits(n)`. */
fun Int.toPersianDigits(): String =
    toString().map { c -> if (c.isDigit()) persianDigits[c - '0'] else c }.joinToString("")

/** Mirrors JS `formatTime(sec)` — H:MM:SS if >= 1 hour, otherwise MM:SS. */
fun formatTime(totalSeconds: Int): String {
    val sec = totalSeconds.coerceAtLeast(0)
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    val mm = m.toString().padStart(2, '0')
    val ss = s.toString().padStart(2, '0')
    return if (h > 0) "$h:$mm:$ss" else "$mm:$ss"
}
