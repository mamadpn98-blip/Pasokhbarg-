package com.example.quizapp.ui.home

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.quizapp.model.Exam
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

/**
 * Kotlin/Compose equivalent of `renderHome()` + `renderHomeList()` +
 * the drawer (`openDrawer()`), edit modal (`openEditExam()`/`saveEditExam()`),
 * and delete confirm + undo (`showConfirm()` + `showUndoToast()` inside
 * `deleteExam()`).
 *
 * Deliberate Compose-idiomatic choices instead of literal CSS/DOM ports
 * (Home was already written this way before these additions, unlike the
 * pixel-faithful Key/Quiz/Result screens):
 *  - the drawer uses [ModalNavigationDrawer] instead of a manually animated
 *    backdrop+panel pair
 *  - the edit/delete confirmations use [AlertDialog] instead of a custom
 *    `.modal-backdrop`/`.modal` composable
 *  - the undo toast uses [SnackbarHostState] instead of a custom
 *    auto-dismissing toast stack; duration is [SnackbarDuration.Short]
 *    (~4s) rather than the JS version's fixed 5000ms — close enough that
 *    it wasn't worth hand-rolling a timer for
 *  - deleted-exam "undo" reinserts at the top of the list rather than the
 *    exact original index (see [HomeViewModel.restoreExam])
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onCreateExam: () -> Unit,
    onOpenResult: (String) -> Unit,
    onResumeExam: (String) -> Unit,
    onNavigateToBrowse: () -> Unit,
    onNavigateToStats: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()
    var sortMenuExpanded by remember { mutableStateOf(false) }
    var editingExam by remember { mutableStateOf<Exam?>(null) }
    var pendingDelete by remember { mutableStateOf<Exam?>(null) }

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            HomeDrawerContent(
                onBrowse = { scope.launch { drawerState.close() }; onNavigateToBrowse() },
                onStats = { scope.launch { drawerState.close() }; onNavigateToStats() },
                onSettings = { scope.launch { drawerState.close() }; onNavigateToSettings() }
            )
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("پاسخ‌برگ تستی") },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "منو")
                        }
                    }
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = onCreateExam) { Icon(Icons.Filled.Add, contentDescription = "آزمون جدید") }
            },
            snackbarHost = { SnackbarHost(snackbarHostState) }
        ) { padding ->
            Column(modifier = Modifier.padding(padding).fillMaxSize()) {

                // ---- home-stats row ----
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatCard("🔥 ${state.streakCount}", "استریک روزانه", Modifier.weight(1f))
                    StatCard("${state.completedCount}", "آزمون‌های تکمیل‌شده", Modifier.weight(1f))
                    StatCard(state.weekAveragePercent?.let { "${it.toInt()}٪" } ?: "—", "میانگین هفته اخیر", Modifier.weight(1f))
                    StatCard(state.overallAveragePercent?.let { "${it}٪" } ?: "—", "میانگین کل", Modifier.weight(1f))
                }

                if (state.hasAnyExamsAtAll) {
                    // ---- search + sort toolbar ----
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = state.search,
                            onValueChange = viewModel::onSearchChanged,
                            placeholder = { Text("جست‌وجو در نام درس، مبحث یا منبع…") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        Box {
                            OutlinedButton(onClick = { sortMenuExpanded = true }) {
                                Text(state.sort.label)
                            }
                            DropdownMenu(expanded = sortMenuExpanded, onDismissRequest = { sortMenuExpanded = false }) {
                                HomeSort.entries.forEach { option ->
                                    DropdownMenuItem(
                                        text = { Text(option.label) },
                                        onClick = {
                                            viewModel.onSortChanged(option)
                                            sortMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                // ---- exam list / empty states ----
                if (state.visibleExams.isEmpty()) {
                    EmptyState(hasAnyExamsAtAll = state.hasAnyExamsAtAll)
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        contentPadding = PaddingValues(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(state.visibleExams, key = { it.id }) { exam ->
                            ExamCard(
                                exam = exam,
                                onClick = {
                                    if (exam.inProgress) onResumeExam(exam.id) else onOpenResult(exam.id)
                                },
                                onEdit = { editingExam = exam },
                                onDelete = { pendingDelete = exam }
                            )
                        }
                        if (state.hasMore) {
                            item(span = { GridItemSpan(maxLineSpan) }) {
                                OutlinedButton(
                                    onClick = viewModel::loadMore,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("نمایش ${minOf(30, state.remainingCount)} آزمون بعدی (${state.remainingCount} مورد باقی‌مانده)")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // ---- edit exam modal: mirrors openEditExam()/saveEditExam() ----
    editingExam?.let { exam ->
        EditExamDialog(
            exam = exam,
            onDismiss = { editingExam = null },
            onSave = { subject, topic, source ->
                viewModel.updateExamDetails(exam.id, subject, topic, source)
                editingExam = null
            }
        )
    }

    // ---- delete confirm + undo: mirrors showConfirm(...) -> deleteExam() -> showUndoToast(...) ----
    pendingDelete?.let { exam ->
        ConfirmDialog(
            message = "این آزمون حذف شود؟",
            confirmLabel = "حذف",
            onDismiss = { pendingDelete = null },
            onConfirm = {
                viewModel.deleteExam(exam.id)
                pendingDelete = null
                scope.launch {
                    val result = snackbarHostState.showSnackbar(
                        message = "آزمون حذف شد",
                        actionLabel = "واگرد",
                        duration = SnackbarDuration.Short
                    )
                    if (result == SnackbarResult.ActionPerformed) viewModel.restoreExam(exam)
                }
            }
        )
    }
}

/** `.drawer-panel` content — mirrors the three `.drawer-item` buttons in `openDrawer()`. */
@Composable
private fun HomeDrawerContent(
    onBrowse: () -> Unit,
    onStats: () -> Unit,
    onSettings: () -> Unit
) {
    ModalDrawerSheet {
        Text(
            "پاسخ‌برگ تستی",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Black,
            modifier = Modifier.padding(horizontal = 22.dp, vertical = 18.dp)
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(MaterialTheme.colorScheme.outlineVariant)
        )
        Spacer(Modifier.height(6.dp))
        DrawerItem(icon = "🗂", label = "مرور تست‌ها", onClick = onBrowse)
        DrawerItem(icon = "📈", label = "آمار و نمودار پیشرفت", onClick = onStats)
        DrawerItem(icon = "⚙", label = "تنظیمات", onClick = onSettings)
    }
}

@Composable
private fun DrawerItem(icon: String, label: String, onClick: () -> Unit) {
    NavigationDrawerItem(
        label = { Text(label, fontWeight = FontWeight.Bold) },
        icon = { Text(icon) },
        selected = false,
        onClick = onClick,
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
    )
}

/** Mirrors `openEditExam(id)` / `saveEditExam(id)` — subject required, topic/source optional. */
@Composable
private fun EditExamDialog(
    exam: Exam,
    onDismiss: () -> Unit,
    onSave: (subject: String, topic: String, source: String) -> Unit
) {
    var subject by remember { mutableStateOf(exam.subject ?: "") }
    var topic by remember { mutableStateOf(exam.topic ?: "") }
    var source by remember { mutableStateOf(exam.source ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ویرایش آزمون") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it; error = null },
                    label = { Text("نام آزمون") },
                    singleLine = true,
                    isError = error != null,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = topic,
                    onValueChange = { topic = it },
                    label = { Text("مبحث (اختیاری)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = source,
                    onValueChange = { source = it },
                    label = { Text("منبع (اختیاری)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                // mirrors `showToast('نام آزمون نمی‌تواند خالی باشد','error')` + markFieldError
                error?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val trimmedSubject = subject.trim()
                if (trimmedSubject.isEmpty()) {
                    error = "نام آزمون نمی‌تواند خالی باشد"
                } else {
                    onSave(trimmedSubject, topic.trim(), source.trim())
                }
            }) { Text("💾 ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

/** Generic equivalent of `showConfirm(message, onConfirm, confirmLabel)`. */
@Composable
private fun ConfirmDialog(
    message: String,
    confirmLabel: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تأیید") },
        text = { Text(message) },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text(confirmLabel, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

@Composable
private fun StatCard(value: String, label: String, modifier: Modifier = Modifier) {
    ElevatedCard(modifier = modifier) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(value, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun EmptyState(hasAnyExamsAtAll: Boolean) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                if (hasAnyExamsAtAll) "نتیجه‌ای پیدا نشد" else "هنوز آزمونی ثبت نشده",
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(6.dp))
            Text(
                if (hasAnyExamsAtAll) "عبارت جست‌وجو یا مرتب‌سازی را تغییر دهید."
                else "برای ساخت اولین آزمون، روی دکمه + بزنید.",
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ExamCard(
    exam: Exam,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    // Long-press reveals edit/delete actions — equivalent of the JS card's
    // 650ms pointerdown timer that adds the `show-delete` class.
    var showActions by remember { mutableStateOf(false) }

    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = { if (showActions) showActions = false else onClick() },
                onLongClick = { showActions = true }
            )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(exam.subject ?: "بدون نام", style = MaterialTheme.typography.titleSmall)
                if (showActions) {
                    Row {
                        TextButton(onClick = onEdit) { Text("✎") }
                        TextButton(onClick = onDelete) { Text("🗑") }
                    }
                }
            }
            Text("مبحث: ${exam.topic ?: "—"}", style = MaterialTheme.typography.bodySmall)
            Text("منبع: ${exam.source ?: "—"}", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(6.dp))
            if (exam.inProgress) {
                Text(
                    "${exam.quizAnswers.size} پاسخ ثبت شده از ${exam.numbers.size}",
                    style = MaterialTheme.typography.labelSmall
                )
                Button(onClick = onClick, modifier = Modifier.fillMaxWidth()) { Text("ادامه آزمون") }
            } else {
                val percent = exam.result?.percent?.toInt() ?: 0
                LinearProgressIndicator(
                    progress = { (percent.coerceIn(0, 100)) / 100f },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "🗓 ${formatDate(exam.createdAt)}",
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    }
}

private fun formatDate(millis: Long): String =
    SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(Date(millis))
