package com.example.quizapp.ui.review

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.quizapp.model.ReviewItem

/**
 * Kotlin/Compose equivalent of `renderReviewKey()`. Same plain-row
 * `.key-mode` look as [com.example.quizapp.ui.key.KeyScreen] — palette
 * values duplicated locally, same as that file already does (no shared
 * palette object exists to pull from instead).
 */
@Composable
fun ReviewKeyScreen(
    viewModel: ReviewKeyViewModel,
    onFinish: (keyAnswers: Map<String, Int>) -> Unit,
    onBack: () -> Unit
) {
    val state by viewModel.state.collectAsState()

    Box(modifier = Modifier.fillMaxSize().background(ReviewKeyPalette.pageBackground)) {
        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 12.dp)) {
            Text(
                "پاسخبرگ تستی",
                color = ReviewKeyPalette.titleColor,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                modifier = Modifier.height(48.dp).wrapContentHeight(Alignment.CenterVertically)
            )
            Spacer(Modifier.height(8.dp))

            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
                Column(
                    modifier = Modifier
                        .widthIn(max = 760.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(ReviewKeyPalette.paperBackground)
                        .border(1.dp, ReviewKeyPalette.paperBorder, RoundedCornerShape(24.dp))
                        .padding(20.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("ورود کلید پاسخ", color = ReviewKeyPalette.titleColor, fontWeight = FontWeight.Black, fontSize = 22.sp)
                            Spacer(Modifier.height(4.dp))
                            Text("برای هر تست، گزینه صحیح را وارد کنید.", color = ReviewKeyPalette.subtitleColor, fontSize = 13.sp)
                        }
                        CountBadge(state.missingItems.size)
                    }

                    Spacer(Modifier.height(12.dp))
                    NoticeBox(
                        "توجه: این تست‌ها در آزمون اصلی نزده بوده‌اند و کلیدی برایشان ثبت نشده؛ " +
                            "برای محاسبه نتیجه آزمون مرور، گزینه صحیح هر تست را وارد کنید."
                    )
                    Spacer(Modifier.height(12.dp))

                    if (state.missingItems.isEmpty()) {
                        NoticeBox("تستی برای ورود کلید باقی نمانده است.")
                    } else {
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                state.missingItems.forEach { item ->
                                    ReviewKeyRow(
                                        item = item,
                                        selected = state.keyAnswers[item.itemKey],
                                        onChoose = { o -> viewModel.choose(item.itemKey, o) }
                                    )
                                }
                            }
                        }
                    }

                    state.errorMessage?.let { msg ->
                        Spacer(Modifier.height(14.dp))
                        WarningBox(msg)
                    }

                    Spacer(Modifier.height(24.dp))
                    Button(
                        onClick = { viewModel.tryFinish()?.let(onFinish) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ReviewKeyPalette.primary)
                    ) { Text("اتمام", fontWeight = FontWeight.Bold) }

                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = onBack,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ReviewKeyPalette.btnSecondaryBg)
                    ) { Text("بازگشت به صفحه قبل", color = ReviewKeyPalette.btnSecondaryText, fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
}

@Composable
private fun CountBadge(count: Int) {
    Box(
        modifier = Modifier.clip(RoundedCornerShape(999.dp)).background(ReviewKeyPalette.countBadgeBg)
            .padding(horizontal = 11.dp, vertical = 7.dp)
    ) {
        Text("$count تست", color = ReviewKeyPalette.countBadgeText, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
private fun NoticeBox(text: String) {
    Box(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(ReviewKeyPalette.noticeBg)
            .border(1.dp, ReviewKeyPalette.noticeBorder, RoundedCornerShape(14.dp)).padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Text(text, color = ReviewKeyPalette.noticeText, fontSize = 13.sp, lineHeight = 20.sp)
    }
}

@Composable
private fun WarningBox(text: String) {
    Box(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(ReviewKeyPalette.warningBg)
            .border(1.dp, ReviewKeyPalette.warningBorder, RoundedCornerShape(14.dp)).padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Text(text, color = ReviewKeyPalette.warningText, fontSize = 13.sp, lineHeight = 20.sp)
    }
}

@Composable
private fun ReviewKeyRow(item: ReviewItem, selected: Int?, onChoose: (Int) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(ReviewKeyPalette.rowBackground)
            .border(1.dp, ReviewKeyPalette.rowBorder, RoundedCornerShape(14.dp)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(modifier = Modifier.width(80.dp), contentAlignment = Alignment.Center) {
            Text(item.n.toString(), color = ReviewKeyPalette.numberColor, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
        }
        Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            (1..4).forEach { option ->
                ReviewKeyOptionButton(
                    option = option,
                    isSelected = selected == option,
                    modifier = Modifier.weight(1f),
                    onClick = { onChoose(option) }
                )
            }
        }
    }
}

@Composable
private fun ReviewKeyOptionButton(option: Int, isSelected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val bg = if (isSelected) ReviewKeyPalette.optSelectedBg else Color(0xFFF8FAFC)
    val textColor = if (isSelected) ReviewKeyPalette.optSelectedText else Color(0xFF334155)
    val borderColor = if (isSelected) ReviewKeyPalette.optSelectedBg else Color(0xFFCBD5E1)

    Box(
        modifier = modifier.heightIn(min = 44.dp).clip(RoundedCornerShape(13.dp)).background(bg)
            .border(1.dp, borderColor, RoundedCornerShape(13.dp)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(option.toString(), color = textColor, fontWeight = FontWeight.Black)
    }
}

private object ReviewKeyPalette {
    val pageBackground = Color(0xFF080C11)
    val paperBackground = Color(0xFF10161E)
    val paperBorder = Color(0xFF222C38)
    val titleColor = Color(0xFFF5F7FA)
    val subtitleColor = Color(0xFF8592A3)
    val countBadgeBg = Color(0xFF1B2531)
    val countBadgeText = Color(0xFFC7D2E0)
    val noticeBg = Color(0xFF182635)
    val noticeBorder = Color(0xFF2A4360)
    val noticeText = Color(0xFFA9C6E6)
    val warningBg = Color(0xFF2A2415)
    val warningBorder = Color(0xFF4A3F1C)
    val warningText = Color(0xFFE8D38A)
    val primary = Color(0xFF4F8CFF)
    val btnSecondaryBg = Color(0xFF1B2531)
    val btnSecondaryText = Color(0xFFDBE4EE)
    val rowBackground = Color(0xFF151B24)
    val rowBorder = Color(0xFF222C38)
    val numberColor = Color(0xFFE7ECF2)
    val optSelectedBg = Color(0xFF000000)
    val optSelectedText = Color(0xFFFFFFFF)
}
