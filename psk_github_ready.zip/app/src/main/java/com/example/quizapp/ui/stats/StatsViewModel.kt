package com.example.quizapp.ui.stats

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.quizapp.data.ExamRepository
import com.example.quizapp.util.StatsUiState
import com.example.quizapp.util.buildStatsState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

/** Kotlin/Compose equivalent of `goStats()` + `renderStats()`. */
class StatsViewModel(repository: ExamRepository) : ViewModel() {

    private val selectedSubject = MutableStateFlow<String?>(null) // null == "همه درس‌ها"

    val state: StateFlow<StatsUiState> = combine(repository.exams, selectedSubject) { exams, subject ->
        buildStatsState(exams, subject)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), StatsUiState())

    /** Mirrors `state.statsSubject='...';renderStats()`. Pass `null` for "همه درس‌ها". */
    fun selectSubject(subject: String?) {
        selectedSubject.value = subject
    }
}
