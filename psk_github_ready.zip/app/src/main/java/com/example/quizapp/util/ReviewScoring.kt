package com.example.quizapp.util

import com.example.quizapp.data.ExamRepository
import com.example.quizapp.model.Exam
import com.example.quizapp.model.ExamResult
import com.example.quizapp.model.ReviewItem
import com.example.quizapp.model.ReviewResult

/**
 * Mirrors `finishReviewQuiz()`: scores every item (wrong = chosen answer,
 * defaulting to 0/"blank", doesn't match the key, also defaulting to 0) and
 * builds the finished review [Exam] ready to hand to [ExamRepository.addExam].
 *
 * [items] must already have every `key` resolved (i.e. [resolvedMissingKeys]
 * — from the review-key screen, if any — already merged in by the caller,
 * or there were no missing keys to begin with).
 */
fun finishReviewExam(subject: String, items: List<ReviewItem>, quizAnswers: Map<String, Int>): Exam {
    val results = items.map { x ->
        val wrong = (quizAnswers[x.itemKey] ?: 0) != (x.key ?: 0)
        ReviewResult(itemKey = x.itemKey, wrong = wrong, wrongCount = if (wrong) 1 else 0)
    }
    val correctCount = results.count { !it.wrong && quizAnswers[it.itemKey] != null }
    val wrongCount = results.count { it.wrong && quizAnswers[it.itemKey] != null }
    val blankCount = results.count { quizAnswers[it.itemKey] == null }
    val now = System.currentTimeMillis()

    return Exam(
        subject = subject,
        numbers = items.map { it.n },
        items = items,
        isReview = true,
        createdAt = now,
        finishedAt = now,
        reviewQuizAnswers = quizAnswers,
        reviewResults = results,
        // mirrors `d.result={correctCount,wrongCount,blankCount}` — no percent/number-lists
        // for review exams, reusing ExamResult purely as a counts container.
        result = ExamResult(correctCount = correctCount, wrongCount = wrongCount, blankCount = blankCount)
    )
}

/** Merges keys entered on the review-key screen into items that were missing one. */
fun applyResolvedKeys(items: List<ReviewItem>, resolvedMissingKeys: Map<String, Int>): List<ReviewItem> =
    items.map { x -> if (x.key == null) x.copy(key = resolvedMissingKeys[x.itemKey] ?: x.key) else x }

/**
 * Mirrors the side effect inside `finishReviewKey()`: newly-entered keys for
 * previously-blank questions are written back onto the *original* base exam
 * too (`baseExam.keyAnswers[x.n]=val; baseExam.result=calculateResult(baseExam)`),
 * not just kept on the review item.
 */
fun writeResolvedKeysBackToBaseExams(
    repository: ExamRepository,
    itemsThatWereMissingKeys: List<ReviewItem>,
    resolvedMissingKeys: Map<String, Int>
) {
    itemsThatWereMissingKeys
        .mapNotNull { x -> x.baseExamId?.let { id -> Triple(id, x.n, resolvedMissingKeys[x.itemKey]) } }
        .filter { (_, _, key) -> key != null }
        .groupBy({ it.first }, { it.second to it.third!! })
        .forEach { (baseExamId, numberToKey) ->
            val baseExam = repository.getExam(baseExamId) ?: return@forEach
            val updatedKeyAnswers = baseExam.keyAnswers.toMutableMap()
            numberToKey.forEach { (n, key) -> updatedKeyAnswers[n] = key }
            val updatedExam = baseExam.copy(keyAnswers = updatedKeyAnswers)
            repository.updateExam(updatedExam.copy(result = calculateResult(updatedExam)))
        }
}
