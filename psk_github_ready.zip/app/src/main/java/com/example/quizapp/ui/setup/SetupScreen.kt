package com.example.quizapp.ui.setup

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Exam-creation wizard — Kotlin/Compose equivalent of `renderSetup()` /
 * `renderWizardStep()`. Three steps, same order, same copy, same validation
 * rules as `wizardNext()` / `startQuiz()`.
 *
 * The subject/topic/source fields use [LabeledAutocompleteField]
 * (`ExposedDropdownMenuBox`) instead of the original's readonly-until-tapped
 * input + custom animated `.suggest-panel` — same practical result (tap or
 * type to filter past values, tap a suggestion to fill it in) via a standard
 * Material3 component rather than a hand-rolled readonly/editable toggle.
 * One simplification: the original explicitly closes every other field's
 * panel when one opens (`closeOtherSuggestFields`); here that's left to
 * Compose's own click-outside-dismiss behavior on each dropdown, which
 * covers the same case in practice without extra shared state.
 */
@Composable
fun SetupScreen(
    viewModel: SetupViewModel,
    onCancel: () -> Unit,
    onReady: (NewExamDraft) -> Unit
) {
    val state by viewModel.state.collectAsState()

    Box(modifier = Modifier.fillMaxSize().background(SetupPalette.pageBackground)) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 12.dp)
        ) {
            Text(
                "پاسخبرگ تستی",
                color = SetupPalette.titleColor,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                modifier = Modifier.height(48.dp).wrapContentHeight(Alignment.CenterVertically)
            )

            Spacer(Modifier.height(8.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(SetupPalette.panelBackground)
                    .border(1.dp, SetupPalette.panelBorder, RoundedCornerShape(22.dp))
                    .padding(20.dp)
            ) {
                Text("آزمون جدید", color = SetupPalette.titleColor, fontWeight = FontWeight.Black, fontSize = 24.sp)
                Spacer(Modifier.height(6.dp))
                Text(
                    "مشخصات و بازه تست‌ها را مرحله‌به‌مرحله وارد کنید.",
                    color = SetupPalette.subtitleColor,
                    fontSize = 13.sp
                )

                Spacer(Modifier.height(18.dp))
                WizardStepsBar(currentStep = state.step)
                Spacer(Modifier.height(10.dp))
                Text(
                    "مرحله ${state.step} از 3 — ${stepLabel(state.step)}",
                    color = SetupPalette.subtitleColor,
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(14.dp))

                when (state.step) {
                    1 -> StepOne(state, viewModel)
                    2 -> StepTwo(state, viewModel)
                    else -> StepThree(state, viewModel)
                }

                state.errorMessage?.let { msg ->
                    Spacer(Modifier.height(14.dp))
                    ErrorBox(msg)
                }

                Spacer(Modifier.height(20.dp))

                Button(
                    onClick = {
                        if (state.step == 3) {
                            viewModel.finish()?.let(onReady)
                        } else {
                            viewModel.next()
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SetupPalette.primary)
                ) {
                    Text(if (state.step == 3) "تأیید و ادامه" else "مرحله بعد", fontWeight = FontWeight.Bold)
                }

                Spacer(Modifier.height(10.dp))

                Button(
                    onClick = { if (!viewModel.back()) onCancel() },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SetupPalette.btnSecondaryBg)
                ) {
                    Text(
                        if (state.step == 1) "انصراف" else "مرحله قبل",
                        color = SetupPalette.btnSecondaryText,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

private fun stepLabel(step: Int) = listOf("مشخصات آزمون", "بازه تست‌ها", "نوع تست‌ها")[step - 1]

@Composable
private fun WizardStepsBar(currentStep: Int) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
        (1..3).forEach { n ->
            val color = when {
                n == currentStep -> SetupPalette.primary
                n < currentStep -> SetupPalette.stepDone
                else -> SetupPalette.stepInactive
            }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(5.dp)
                    .clip(RoundedCornerShape(999.dp))
                    .background(color)
            )
        }
    }
}

// ---------------- Step 1: مشخصات آزمون ----------------
@Composable
private fun StepOne(state: SetupUiState, vm: SetupViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        LabeledAutocompleteField(
            label = "نام درس",
            value = state.data.subject,
            onValueChange = vm::updateSubject,
            suggestions = vm.suggestionsFor("subject", state.data.subject),
            placeholder = "مثلاً زیست‌شناسی",
            isInvalid = "subject" in state.invalidFields
        )
        LabeledAutocompleteField(
            label = "نام مبحث",
            value = state.data.topic,
            onValueChange = vm::updateTopic,
            suggestions = vm.suggestionsFor("topic", state.data.topic),
            placeholder = "مثلاً فصل سوم"
        )
        LabeledAutocompleteField(
            label = "نام کتاب / منبع تست",
            value = state.data.source,
            onValueChange = vm::updateSource,
            suggestions = vm.suggestionsFor("source", state.data.source),
            placeholder = "مثلاً زیست دهم"
        )

        Column {
            Text("زمان آزمون", color = SetupPalette.titleColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            SegmentChip(
                label = "آزمون زمان‌دار",
                selected = state.data.timed,
                onClick = { vm.setTimed(!state.data.timed) }
            )
            if (state.data.timed) {
                Spacer(Modifier.height(12.dp))
                LabeledTextField(
                    label = "زمان کل آزمون (دقیقه)",
                    value = state.data.durationMinutes,
                    onValueChange = vm::updateDurationMinutes,
                    placeholder = "40",
                    keyboardType = KeyboardType.Number,
                    isInvalid = "durationMinutes" in state.invalidFields,
                    modifier = Modifier.width(150.dp)
                )
                Spacer(Modifier.height(6.dp))
                Text("مثلاً 40 دقیقه", color = SetupPalette.subtitleColor, fontSize = 12.sp)
            }
        }
    }
}

// ---------------- Step 2: بازه تست‌ها ----------------
@Composable
private fun StepTwo(state: SetupUiState, vm: SetupViewModel) {
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            LabeledTextField(
                label = "از سوال",
                value = state.data.start,
                onValueChange = vm::updateStart,
                placeholder = "1",
                keyboardType = KeyboardType.Number,
                isInvalid = "start" in state.invalidFields,
                modifier = Modifier.width(110.dp)
            )
            LabeledTextField(
                label = "تا سوال",
                value = state.data.end,
                onValueChange = vm::updateEnd,
                placeholder = "2000",
                keyboardType = KeyboardType.Number,
                isInvalid = "end" in state.invalidFields,
                modifier = Modifier.width(110.dp)
            )
        }
        state.liveCount?.let { count ->
            Spacer(Modifier.height(10.dp))
            LiveCountChip(count)
        }
        Spacer(Modifier.height(16.dp))
        NoticeBox("حداکثر تعداد تست در هر آزمون 201 تست است. شماره تست می‌تواند هر عدد صحیحی باشد.")
    }
}

// ---------------- Step 3: نوع تست‌ها ----------------
@Composable
private fun StepThree(state: SetupUiState, vm: SetupViewModel) {
    Column {
        Text("نوع تست‌ها", color = SetupPalette.titleColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(Modifier.height(8.dp))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Parity.entries.forEach { p ->
                SegmentChip(
                    label = p.label,
                    selected = state.data.parity == p,
                    onClick = { vm.setParity(p) },
                    fillWidth = true
                )
            }
        }
    }
}

// ---------------- shared bits ----------------

@Composable
private fun LabeledTextField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    isInvalid: Boolean = false,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Text(label, color = SetupPalette.titleColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            placeholder = { Text(placeholder, color = SetupPalette.subtitleColor) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
            isError = isInvalid,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = SetupPalette.inputBackground,
                unfocusedContainerColor = SetupPalette.inputBackground,
                focusedBorderColor = if (isInvalid) SetupPalette.invalidBorder else SetupPalette.primary,
                unfocusedBorderColor = if (isInvalid) SetupPalette.invalidBorder else SetupPalette.inputBorder,
                focusedTextColor = SetupPalette.titleColor,
                unfocusedTextColor = SetupPalette.titleColor
            )
        )
    }
}

/**
 * Mirrors the `.autocomplete-field` + `.suggest-panel` combo: tap (or type)
 * to see up to 8 frequency-sorted past values for this field, tap one to
 * fill it in, or just keep typing to enter something new. Built on
 * [ExposedDropdownMenuBox] instead of the original's readonly/editable
 * toggle — see the doc comment on [SetupScreen] for why.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LabeledAutocompleteField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    suggestions: List<String>,
    placeholder: String,
    isInvalid: Boolean = false,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    val showMenu = expanded && suggestions.isNotEmpty()

    Column(modifier = modifier) {
        Text(label, color = SetupPalette.titleColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(Modifier.height(8.dp))
        ExposedDropdownMenuBox(
            expanded = showMenu,
            onExpandedChange = { expanded = it }
        ) {
            OutlinedTextField(
                value = value,
                onValueChange = {
                    onValueChange(it)
                    expanded = true // mirrors `onSuggestInput()` re-opening/re-filtering the panel while typing
                },
                placeholder = { Text(placeholder, color = SetupPalette.subtitleColor) },
                singleLine = true,
                isError = isInvalid,
                modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryEditable, true),
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = SetupPalette.inputBackground,
                    unfocusedContainerColor = SetupPalette.inputBackground,
                    focusedBorderColor = if (isInvalid) SetupPalette.invalidBorder else SetupPalette.primary,
                    unfocusedBorderColor = if (isInvalid) SetupPalette.invalidBorder else SetupPalette.inputBorder,
                    focusedTextColor = SetupPalette.titleColor,
                    unfocusedTextColor = SetupPalette.titleColor
                )
            )
            // mirrors `.suggest-panel .suggest-chip` — up to 8 frequency-sorted, filtered chips
            ExposedDropdownMenu(expanded = showMenu, onDismissRequest = { expanded = false }) {
                suggestions.forEach { s ->
                    DropdownMenuItem(
                        text = { Text(s) },
                        onClick = {
                            onValueChange(s)
                            expanded = false
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun SegmentChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    fillWidth: Boolean = false
) {
    Box(
        modifier = (if (fillWidth) Modifier.fillMaxWidth() else Modifier)
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) SetupPalette.segmentActiveBg else SetupPalette.segmentBg)
            .border(
                1.dp,
                if (selected) SetupPalette.primary else SetupPalette.panelBorder,
                RoundedCornerShape(14.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 15.dp, vertical = 12.dp)
    ) {
        Text(label, color = SetupPalette.titleColor, fontWeight = FontWeight.Medium, fontSize = 14.sp)
    }
}

@Composable
private fun LiveCountChip(count: Int) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(SetupPalette.liveCountBg)
            .border(1.dp, SetupPalette.liveCountBorder, RoundedCornerShape(999.dp))
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text("🔢 تعداد تست‌ها: $count", color = SetupPalette.liveCountText, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
    }
}

@Composable
private fun NoticeBox(text: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(SetupPalette.noticeBg)
            .border(1.dp, SetupPalette.noticeBorder, RoundedCornerShape(14.dp))
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Text(text, color = SetupPalette.noticeText, fontSize = 13.sp, lineHeight = 20.sp)
    }
}

@Composable
private fun ErrorBox(text: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(SetupPalette.errorBg)
            .border(1.dp, SetupPalette.errorBorder, RoundedCornerShape(14.dp))
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Text(text, color = SetupPalette.errorText, fontSize = 13.sp, lineHeight = 20.sp)
    }
}

private object SetupPalette {
    val pageBackground = Color(0xFF080C11)
    val panelBackground = Color(0xFF141D2A)
    val panelBorder = Color(0xFF293A4F)
    val titleColor = Color(0xFFF5F7FA)
    val subtitleColor = Color(0xFF8592A3)
    val primary = Color(0xFF4F8CFF)
    val btnSecondaryBg = Color(0xFF1B2531)
    val btnSecondaryText = Color(0xFFDBE4EE)
    val inputBackground = Color(0xFF0C1219)
    val inputBorder = Color(0xFF263241)
    val invalidBorder = Color(0xFFEF4444)
    val segmentBg = Color(0xFF111B28)
    val segmentActiveBg = Color(0xFF1E2A3D)
    val stepInactive = Color(0xFF253447)
    val stepDone = Color(0xFF536BA0)
    val noticeBg = Color(0xFF182635)
    val noticeBorder = Color(0xFF2A4360)
    val noticeText = Color(0xFFA9C6E6)
    val liveCountBg = Color(0xFF0D2038)
    val liveCountBorder = Color(0xFF204A7C)
    val liveCountText = Color(0xFFB9D7FF)
    val errorBg = Color(0xFF33171A)
    val errorBorder = Color(0xFF6D252C)
    val errorText = Color(0xFFFECACA)
}
