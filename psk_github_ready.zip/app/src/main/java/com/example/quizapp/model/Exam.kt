package com.example.quizapp.model

import java.util.UUID

/**
 * Result summary for a finished exam (mirrors `e.result` in the JS version,
 * i.e. the object returned by `calculateResult(e)`).
 *
 * [correctNumbers]/[wrongNumbers]/[blankNumbers] mirror the JS `correct` /
 * `wrong` / `blank` arrays of question numbers — the result screen's
 * filter tabs (all/correct/wrong/blank) and per-card status are derived
 * straight from these, exactly like `resultContent()` does.
 */
data class ExamResult(
    val correctCount: Int = 0,
    val wrongCount: Int = 0,
    val blankCount: Int = 0,
    val percent: Double = 0.0,
    val correctNumbers: List<Int> = emptyList(),
    val wrongNumbers: List<Int> = emptyList(),
    val blankNumbers: List<Int> = emptyList(),
    // mirrors `r.time` (seconds spent answering) — separate from Exam.elapsedTimeSeconds
    // because a review exam's "time" isn't meaningful/displayed the same way.
    val timeSeconds: Long = 0L
)

/**
 * A single item inside a review exam (mirrors `d.items[i]` in createReviewQuiz()).
 */
data class ReviewItem(
    val itemKey: String,
    val baseExamId: String?,
    val n: Int,
    val user: Int? = null,
    val key: Int? = null,
    val source: String? = null,
    val topic: String? = null
)

data class ReviewResult(
    val itemKey: String,
    val wrong: Boolean,
    val wrongCount: Int = 0
)

/**
 * The core Exam entity.
 *
 * NOTE ON THE BUG WE JUST FIXED IN THE JS VERSION:
 * `isReview` must be respected everywhere the home list is built — the Kotlin
 * repository/view-model layer filters on this flag instead of relying on every
 * call site to remember to do so, which is what caused the original bug.
 */
data class Exam(
    val id: String = UUID.randomUUID().toString(),
    val subject: String? = null,
    val topic: String? = null,
    val source: String? = null,
    val numbers: List<Int> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val finishedAt: Long? = null,

    val inProgress: Boolean = false,
    val isReview: Boolean = false,

    // mirrors `e.timed` / `e.durationMinutes`, set by the setup wizard — needed
    // on the result screen to show "زمان پاسخ‌گویی: X از Y" for timed exams.
    val timed: Boolean = false,
    val durationMinutes: Int? = null,

    // answers keyed by item number (regular exam) — mirrors quizAnswers / keyAnswers
    val quizAnswers: Map<Int, Int> = emptyMap(),
    val keyAnswers: Map<Int, Int> = emptyMap(),

    val result: ExamResult? = null,
    val elapsedTimeSeconds: Long? = null,

    // review-exam-only fields
    val reviewName: String? = null,
    val items: List<ReviewItem> = emptyList(),
    val reviewResults: List<ReviewResult> = emptyList(),
    // review exams store their own answers separately from a base exam's quizAnswers
    val reviewQuizAnswers: Map<String, Int> = emptyMap()
) {
    /** Convenience mirror of the JS `baseExams()` helper. */
    fun isBaseExam(): Boolean = !inProgress && !isReview
}
