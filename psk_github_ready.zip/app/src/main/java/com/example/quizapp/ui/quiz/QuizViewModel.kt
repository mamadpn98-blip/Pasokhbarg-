package com.example.quizapp.ui.quiz

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class QuizUiState(
    val numbers: List<Int> = emptyList(),
    val answers: Map<Int, Int> = emptyMap(), // question number -> chosen option (1..4)
    val groupSize: GroupSize = GroupSize.FIVE,
    val theme: SheetTheme = SheetTheme.BLUE,
    val isTimed: Boolean = false,
    val timerSeconds: Int = 0,
    val timerIsWarning: Boolean = false // last 60 seconds, mirrors .timer-warning
)

class QuizViewModel(
    numbers: List<Int>,
    isTimed: Boolean = false,
    durationMinutes: Int = 0,
    groupSize: GroupSize = GroupSize.FIVE,
    theme: SheetTheme = SheetTheme.BLUE,
    // mirrors `resumeExam(id)` restoring `e.quizAnswers` and remaining/elapsed time
    existingAnswers: Map<Int, Int> = emptyMap(),
    initialElapsedSeconds: Int = 0
) : ViewModel() {

    private val durationMinutesValue = durationMinutes

    private val _state = MutableStateFlow(
        QuizUiState(
            numbers = numbers.sorted(),
            answers = existingAnswers,
            isTimed = isTimed,
            // countdown remaining when timed, stopwatch elapsed-so-far when not (see startStopwatch())
            timerSeconds = if (isTimed) (durationMinutes * 60 - initialElapsedSeconds).coerceAtLeast(0) else initialElapsedSeconds,
            timerIsWarning = isTimed && (durationMinutes * 60 - initialElapsedSeconds) <= 60,
            groupSize = groupSize,
            theme = theme
        )
    )
    val state: StateFlow<QuizUiState> = _state.asStateFlow()

    init {
        if (isTimed) startCountdown() else startStopwatch()
    }

    /** Mirrors JS `choose(n, o)`: tapping the already-selected option clears it. */
    fun choose(number: Int, option: Int) {
        _state.update { s ->
            val current = s.answers.toMutableMap()
            if (current[number] == option) current.remove(number) else current[number] = option
            s.copy(answers = current)
        }
    }

    fun setGroupSize(value: GroupSize) {
        _state.update { it.copy(groupSize = value) }
    }

    fun setTheme(value: SheetTheme) {
        _state.update { it.copy(theme = value) }
    }

    private var onTimeExpired: (() -> Unit)? = null
    fun setOnTimeExpired(callback: () -> Unit) {
        onTimeExpired = callback
    }

    private fun startCountdown() {
        viewModelScope.launch {
            while (_state.value.timerSeconds > 0) {
                delay(1000)
                _state.update {
                    val next = (it.timerSeconds - 1).coerceAtLeast(0)
                    it.copy(timerSeconds = next, timerIsWarning = next <= 60)
                }
            }
            if (_state.value.isTimed) onTimeExpired?.invoke()
        }
    }

    /** Untimed exams don't show a chip (see [state]'s `isTimed` guard in the screen) but still need an elapsed-time stopwatch for [elapsedSecondsForSave]. */
    private fun startStopwatch() {
        viewModelScope.launch {
            while (true) {
                delay(1000)
                _state.update { it.copy(timerSeconds = it.timerSeconds + 1) }
            }
        }
    }

    /** Mirrors `finishQuiz()`'s `state.elapsedSeconds` calculation — what the caller should store as `Exam.elapsedTimeSeconds`. */
    fun elapsedSecondsForSave(): Int {
        val s = _state.value
        return if (s.isTimed) (durationMinutesValue * 60 - s.timerSeconds).coerceAtLeast(0) else s.timerSeconds
    }

    fun answeredCount(): Int = _state.value.answers.size
    fun totalCount(): Int = _state.value.numbers.size
}
