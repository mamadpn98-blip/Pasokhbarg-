package com.example.quizapp.ui.result

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.quizapp.util.formatTime
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

/**
 * Kotlin/Compose equivalent of `renderResult()`.
 *
 * Layout mirrors the original 1:1: brand-only topbar (no back button — the
 * JS version relies solely on the bottom "بازگشت به صفحه اصلی" button),
 * a single `.panel` card holding the ring+stats hero, the four filter tabs,
 * and the answer-card list.
 */
@Composable
fun ResultScreen(
    viewModel: ResultViewModel,
    onBackToHome: () -> Unit
) {
    val state by viewModel.state.collectAsState()
    var showConfetti by remember(state.shouldCelebrate) { mutableStateOf(state.shouldCelebrate) }

    Box(modifier = Modifier.fillMaxSize().background(ResultPalette.pageBackground)) {
        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 12.dp)) {
            // ---- topbar: brand only, no back icon — matches the HTML exactly ----
            Text(
                "نتیجه آزمون",
                color = ResultPalette.text,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                modifier = Modifier.height(48.dp).wrapContentHeight(Alignment.CenterVertically)
            )

            Spacer(Modifier.height(8.dp))

            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(ResultPalette.panelBackground)
                    .border(1.dp, ResultPalette.panelBorder, RoundedCornerShape(22.dp))
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    state.subject,
                    color = ResultPalette.text,
                    fontWeight = FontWeight.Black,
                    fontSize = 22.sp
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    buildSubtitle(state),
                    color = ResultPalette.muted,
                    fontSize = 13.sp,
                    lineHeight = 20.sp
                )

                Spacer(Modifier.height(16.dp))
                ResultTopCard(state)

                Spacer(Modifier.height(16.dp))
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    ResultFilterRow(selected = state.tab, onSelect = viewModel::setTab)
                }

                Spacer(Modifier.height(16.dp))
                if (state.visibleItems.isEmpty()) {
                    Text(
                        "تستی برای نمایش وجود ندارد.",
                        color = ResultPalette.muted,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 30.dp)
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        state.visibleItems.forEach { item -> ResultCard(item) }
                    }
                }

                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = onBackToHome,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ResultPalette.primary)
                ) { Text("بازگشت به صفحه اصلی", fontWeight = FontWeight.Bold) }
            }
        }

        // mirrors `if((e.result?.percent??0)>=80)fireConfetti()`, fired once on entry
        if (showConfetti) {
            ConfettiOverlay(onFinished = { showConfetti = false })
        }
    }
}

/** Mirrors `${topic} · ${source}${createdAt ? ' · 🗓 '+formatDate(createdAt) : ''}` exactly (empty parts stay as empty, not filtered out). */
private fun buildSubtitle(state: ResultUiState): String {
    var text = "${state.topic} · ${state.source}"
    state.createdAtMillis?.let { millis ->
        val date = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(Date(millis))
        text += " · 🗓 $date"
    }
    return text
}

@Composable
private fun ResultTopCard(state: ResultUiState) {
    val band = percentColor(state.result.percent)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(ResultPalette.surface2) // .result-top-card{background:var(--surface2)}
            .border(1.dp, ResultPalette.panelBorder, RoundedCornerShape(22.dp))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ResultRing(percent = state.result.percent, band = band)
        Spacer(Modifier.height(10.dp))
        Text(
            buildString {
                append("زمان پاسخ‌گویی: ")
                append(formatTime(state.result.timeSeconds.toInt()))
                if (state.isTimed && (state.durationMinutes ?: 0) > 0) {
                    append("  از ")
                    append(formatTime((state.durationMinutes ?: 0) * 60))
                }
            },
            color = ResultPalette.muted,
            fontSize = 13.sp
        )

        Spacer(Modifier.height(20.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ResultStatItem(state.totalCount.toString(), "همه تست‌ها", Modifier.weight(1f))
            ResultStatItem(state.result.correctCount.toString(), "تست‌های صحیح", Modifier.weight(1f))
            ResultStatItem(state.result.wrongCount.toString(), "تست‌های غلط", Modifier.weight(1f))
            ResultStatItem(state.result.blankCount.toString(), "تست‌های نزده", Modifier.weight(1f))
        }
    }
}

/**
 * `.result-ring{background:conic-gradient(ringColor fillPct%, #222c38 0)}` +
 * `.result-ring-inner` (a smaller circle in `--surface2` on top, to leave a
 * donut-shaped band) + the centered percent label.
 */
@Composable
private fun ResultRing(percent: Double, band: ResultBand) {
    val color = ResultPalette.ringColor(band)
    val fillPct = percent.coerceIn(0.0, 100.0)
    Box(modifier = Modifier.size(152.dp), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            // full-circle base (the "#222c38 0" remainder of the two-stop conic-gradient)
            drawArc(
                color = ResultPalette.ringTrack,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = true
            )
            if (fillPct > 0) {
                drawArc(
                    color = color,
                    startAngle = -90f,
                    sweepAngle = (360f * (fillPct / 100f)).toFloat(),
                    useCenter = true
                )
            }
            // .result-ring-inner: 118dp inside a 152dp ring -> hollow it out to a donut
            val holeRadius = size.minDimension / 2f * (118f / 152f)
            drawCircle(color = ResultPalette.surface2, radius = holeRadius, center = center)
        }
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Text(
                "${"%.1f".format(percent)}٪",
                color = ResultPalette.text,
                fontWeight = FontWeight.Black,
                fontSize = 22.sp
            )
        }
    }
}

@Composable
private fun ResultStatItem(value: String, label: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(ResultPalette.surface3)
            .border(1.dp, ResultPalette.panelBorder, RoundedCornerShape(16.dp))
            .padding(vertical = 14.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, color = ResultPalette.text, fontWeight = FontWeight.Black, fontSize = 22.sp)
        Spacer(Modifier.height(5.dp))
        Text(label, color = ResultPalette.muted, fontSize = 11.5.sp, textAlign = TextAlign.Center)
    }
}

/** `.result-filter-row` — four tabs, active one filled with `--primary`. */
@Composable
private fun ResultFilterRow(selected: ResultTab, onSelect: (ResultTab) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        ResultTab.entries.forEach { tab ->
            val active = tab == selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (active) ResultPalette.primary else ResultPalette.surface2)
                    .border(
                        1.dp,
                        if (active) ResultPalette.primary else ResultPalette.panelBorder,
                        RoundedCornerShape(14.dp)
                    )
                    .clickableNoRipple { onSelect(tab) }
                    .padding(vertical = 13.dp, horizontal = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    tab.label,
                    color = if (active) Color.White else ResultPalette.text,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.5.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

/**
 * One row of `.result-cards-grid` — `resultItem(e,n,cls)`. Digits are plain
 * (not `toPersianDigits()`), matching the original `تست ${n}` / `${user}` /
 * `${key}` template literals exactly.
 */
@Composable
private fun ResultCard(item: ResultCardUi) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(ResultPalette.cardGradient(item.status))
            .border(1.dp, ResultPalette.cardBorder(item.status), RoundedCornerShape(10.dp))
            .padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "تست ${item.number}",
            color = ResultPalette.text,
            fontWeight = FontWeight.Black,
            fontSize = 15.sp
        )
        Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            Text(
                "جواب شما: ${item.userAnswer ?: "—"}",
                color = ResultPalette.text,
                fontSize = 12.5.sp
            )
            Text(
                "گزینه صحیح: ${item.correctAnswer ?: "—"}",
                color = ResultPalette.text,
                fontSize = 12.5.sp
            )
        }
    }
}

/** `Modifier.clickable` with no ripple/indication, matching flat CSS buttons. */
@Composable
private fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier = this.clickable(
    interactionSource = remember { MutableInteractionSource() },
    indication = null,
    onClick = onClick
)

/**
 * Lightweight equivalent of the JS `fireConfetti()` canvas animation: ~90
 * rectangular pieces fall from above the screen with random drift/rotation
 * for ~3 seconds, then remove themselves — same idea as the original
 * `requestAnimationFrame` loop, just driven by Compose's frame clock.
 */
@Composable
private fun ConfettiOverlay(onFinished: () -> Unit) {
    val colors = remember {
        listOf(
            Color(0xFF4F8CFF), Color(0xFF22C55E), Color(0xFFEAB308),
            Color(0xFFEF4444), Color(0xFF14B8A6), Color(0xFFF472B6)
        )
    }
    data class Piece(
        var x: Float, var y: Float, val w: Float, val h: Float,
        val color: Color, var rot: Float, val vRot: Float, val vy: Float, val vx: Float
    )

    val pieces = remember {
        List(90) {
            Piece(
                x = Random.nextFloat(),
                y = -0.2f - Random.nextFloat() * 0.4f,
                w = 6f + Random.nextFloat() * 6f,
                h = 9f + Random.nextFloat() * 7f,
                color = colors[Random.nextInt(colors.size)],
                rot = Random.nextFloat() * 360f,
                vRot = (Random.nextFloat() - 0.5f) * 10f,
                vy = 0.006f + Random.nextFloat() * 0.008f,
                vx = (Random.nextFloat() - 0.5f) * 0.004f
            )
        }
    }
    var tick by remember { mutableStateOf(0) }

    LaunchedEffect(Unit) {
        val start = System.currentTimeMillis()
        while (System.currentTimeMillis() - start < 3000) {
            pieces.forEach { p ->
                p.x += p.vx
                p.y += p.vy
                p.rot += p.vRot
            }
            tick++
            delay(16)
        }
        onFinished()
    }

    Canvas(modifier = Modifier.fillMaxSize()) {
        tick // read to force recomposition of this draw scope each frame
        pieces.forEach { p ->
            val cx = p.x * size.width
            val cy = p.y * size.height
            translate(left = cx, top = cy) {
                rotate(degrees = p.rot, pivot = Offset.Zero) {
                    drawRect(
                        color = p.color,
                        topLeft = Offset(-p.w / 2f, -p.h / 2f),
                        size = Size(p.w, p.h)
                    )
                }
            }
        }
    }
}
