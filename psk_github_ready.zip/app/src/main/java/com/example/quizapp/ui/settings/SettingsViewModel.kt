package com.example.quizapp.ui.settings

import androidx.lifecycle.ViewModel
import com.example.quizapp.data.AppSettings
import com.example.quizapp.data.ExamRepository
import com.example.quizapp.data.SettingsRepository
import com.example.quizapp.ui.quiz.GroupSize
import com.example.quizapp.ui.quiz.SheetTheme
import com.example.quizapp.util.ScoringSettings
import com.example.quizapp.util.recalculateAllExamResults
import com.google.gson.JsonParser
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Kotlin/Compose equivalent of `renderSettings()` + `setGroupSize()` +
 * `setTheme()` + `setScoreCoefficient()` + `backupToFile()`/`restoreFromFile()`.
 *
 * Actual file I/O (Storage Access Framework document picker/writer) needs an
 * `Activity`, which doesn't exist anywhere in this project yet — see
 * [SettingsScreen] for exactly where that glue plugs in.
 */
class SettingsViewModel(
    private val settingsRepository: SettingsRepository,
    private val examRepository: ExamRepository
) : ViewModel() {

    val settings: StateFlow<AppSettings> = settingsRepository.settings

    private val _pendingImportJson = MutableStateFlow<String?>(null)
    /** Non-null while the "⚠️ آیا اطلاعات فعلی جایگزین شود؟" confirm dialog should be showing. */
    val pendingImportJson: StateFlow<String?> = _pendingImportJson.asStateFlow()

    private val _resultMessage = MutableStateFlow<String?>(null)
    /** One-shot toast-equivalent message (✅/❌ …); screen should call [consumeResultMessage] after showing it. */
    val resultMessage: StateFlow<String?> = _resultMessage.asStateFlow()

    /** Mirrors `setGroupSize(v)`. */
    fun setGroupSize(groupSize: GroupSize) = settingsRepository.setGroupSize(groupSize)

    /** Mirrors `setTheme(v)`. */
    fun setTheme(theme: SheetTheme) = settingsRepository.setTheme(theme)

    /** Mirrors `setScoreCoefficient()`: validates, persists, then recalculates every base exam's result. */
    fun setScoreCoefficients(scoreCorrect: Int, scoreWrongPenalty: Int) {
        val ok = settingsRepository.setScoreCoefficients(scoreCorrect, scoreWrongPenalty)
        if (ok) {
            recalculateAllExamResults(examRepository, ScoringSettings(scoreCorrect, scoreWrongPenalty))
            _resultMessage.value = "نحوه نمره‌گذاری به‌روزرسانی شد"
        }
        // JS silently no-ops on invalid input too (`if(!Number.isFinite(n)||n<0)return`) — no error message.
    }

    /** Mirrors `backupToFile()`'s JSON payload — writing it to a file is the caller's job (see [SettingsScreen]). */
    fun exportBackupJson(): String = examRepository.exportBackupJson()

    /**
     * Called once the caller has read the user-picked backup file's text.
     * Mirrors the validity pre-check at the top of `restoreFromFile()` (JSON
     * parses AND is an array or `{exams:[...]}`) — if it fails here, no
     * confirm dialog is shown, same as the original.
     */
    fun stagePendingImport(json: String) {
        val looksValid = try {
            val root = JsonParser.parseString(json)
            root.isJsonArray || (root.isJsonObject && root.asJsonObject.has("exams"))
        } catch (e: Exception) {
            false
        }
        if (!looksValid) {
            _resultMessage.value = "❌ فایل پشتیبان معتبر نیست"
            return
        }
        _pendingImportJson.value = json
    }

    /** Mirrors dismissing `showConfirm()` without choosing "✅ جایگزینی". */
    fun cancelPendingImport() {
        _pendingImportJson.value = null
    }

    /** Mirrors the `showConfirm(...)` callback in `restoreFromFile()`: replaces the whole exam list. */
    fun confirmPendingImport() {
        val json = _pendingImportJson.value ?: return
        _pendingImportJson.value = null
        val count = examRepository.importBackupJson(json)
        _resultMessage.value = if (count != null) "✅ بازیابی با موفقیت انجام شد" else "❌ فایل پشتیبان معتبر نیست"
    }

    fun consumeResultMessage() {
        _resultMessage.value = null
    }
}
