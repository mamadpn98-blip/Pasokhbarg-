package com.example.quizapp.ui.browse

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/** Kotlin/Compose equivalent of `renderBrowseList()`. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowseListScreen(
    viewModel: BrowseListViewModel,
    onBack: () -> Unit,
    onOpenSubject: (String) -> Unit,
    onOpenReviewTests: (String) -> Unit
) {
    val state by viewModel.state.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("مرور تست‌ها") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "بازگشت") } }
            )
        }
    ) { padding ->
        if (state.subjects.isEmpty()) {
            Box(modifier = Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("تست غلط یا نزده‌ای برای مرور وجود ندارد.", style = MaterialTheme.typography.bodyMedium)
            }
        } else {
            LazyColumn(
                modifier = Modifier.padding(padding).fillMaxSize(),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(state.subjects, key = { it.subject }) { s ->
                    ElevatedCard(onClick = { onOpenSubject(s.subject) }, modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(s.subject, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("${s.count} تست", style = MaterialTheme.typography.bodySmall)
                                // mirrors the 📝 `.bi-arrow` icon that opens `openReviewTests(subject)`
                                TextButton(onClick = { onOpenReviewTests(s.subject) }) { Text("📝") }
                            }
                        }
                    }
                }
            }
        }
    }
}
