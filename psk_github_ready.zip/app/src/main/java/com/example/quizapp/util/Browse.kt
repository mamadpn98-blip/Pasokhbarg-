package com.example.quizapp.util

import com.example.quizapp.model.Exam
import com.example.quizapp.model.ExamResult

/** Which bucket a browse item falls in — a base exam only ever shows wrong/blank items. */
enum class BrowseStatus { WRONG, BLANK }

/** One row of `.result-cards-grid` on the browse-subject screen — mirrors `getSubjectItems()`'s map values. */
data class BrowseItem(
    val itemKey: String,
    val baseExamId: String,
    val number: Int,
    val status: BrowseStatus,
    val source: String,
    val topic: String,
    val userAnswer: Int?,
    val correctAnswer: Int?,
    // mirrors the ★ badge: "this item was answered wrong again in a review exam"
    val reviewWrongCount: Int = 0
)

/** One subject card on the browse-list screen — mirrors `getBrowseSubjects()`'s return shape. */
data class BrowseSubjectSummary(val subject: String, val count: Int)

/** Mirrors `itemIdentity(e,n)`. */
fun itemIdentity(exam: Exam, number: Int): String =
    "${exam.subject ?: "بدون نام"}|${exam.source ?: "—"}|$number"

/** Mirrors `calcResultOf(e)`: `e.result||calculateResult(e)`. */
fun calcResultOf(exam: Exam): ExamResult = exam.result ?: calculateResult(exam)

/**
 * Mirrors `getBrowseSubjects()`: for every base (non-in-progress, non-review)
 * exam, count distinct wrong/blank items per subject, deduped by [itemIdentity]
 * so the same question repeated across exams with the same subject+source+
 * number only counts once.
 */
fun getBrowseSubjects(exams: List<Exam>): List<BrowseSubjectSummary> {
    val keysBySubject = LinkedHashMap<String, MutableSet<String>>()
    exams.filter { it.isBaseExam() }.forEach { exam ->
        val r = calcResultOf(exam)
        val subject = exam.subject ?: "بدون نام"
        (r.wrongNumbers + r.blankNumbers).forEach { n ->
            keysBySubject.getOrPut(subject) { mutableSetOf() }.add(itemIdentity(exam, n))
        }
    }
    return keysBySubject.map { (subject, keys) -> BrowseSubjectSummary(subject, keys.size) }
        .sortedBy { it.subject } // simplification: plain lexicographic, not fa-locale collation
}

/**
 * Mirrors `getSubjectItems(subject)`: every wrong/blank question for the given
 * subject across all base exams, deduped by [itemIdentity], with the ★
 * review-mistake flag attached from any review exam that re-tested it.
 */
fun getSubjectItems(exams: List<Exam>, subject: String): List<BrowseItem> {
    val map = LinkedHashMap<String, BrowseItem>()
    exams.filter { it.isBaseExam() && (it.subject ?: "بدون نام") == subject }.forEach { exam ->
        val r = calcResultOf(exam)
        exam.numbers.forEach { n ->
            val status = when {
                r.wrongNumbers.contains(n) -> BrowseStatus.WRONG
                r.blankNumbers.contains(n) -> BrowseStatus.BLANK
                else -> return@forEach
            }
            val key = itemIdentity(exam, n)
            if (!map.containsKey(key)) {
                map[key] = BrowseItem(
                    itemKey = key,
                    baseExamId = exam.id,
                    number = n,
                    status = status,
                    source = exam.source ?: "—",
                    topic = exam.topic ?: "—",
                    userAnswer = exam.quizAnswers[n],
                    correctAnswer = exam.keyAnswers[n]
                )
            }
        }
    }
    // `Math.max(x.reviewWrongCount||0, rr.wrongCount||1)` in the JS — effectively a
    // "was this ever wrong again" flag rather than an accumulating counter.
    exams.filter { it.isReview }.forEach { reviewExam ->
        reviewExam.reviewResults.filter { it.wrong }.forEach { rr ->
            map[rr.itemKey]?.let { item -> map[rr.itemKey] = item.copy(reviewWrongCount = maxOf(item.reviewWrongCount, 1)) }
        }
    }
    return map.values.toList()
}

fun getAvailableSources(exams: List<Exam>, subject: String, status: BrowseStatus?): List<String> =
    getSubjectItems(exams, subject).filter { status == null || it.status == status }
        .map { it.source }.distinct().sorted()

fun getAvailableTopics(exams: List<Exam>, subject: String, status: BrowseStatus?): List<String> =
    getSubjectItems(exams, subject).filter { status == null || it.status == status }
        .map { it.topic }.distinct().sorted()
