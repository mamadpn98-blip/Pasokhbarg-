package com.example.quizapp.ui.key

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class KeyUiState(
    val numbers: List<Int> = emptyList(), // question numbers that were answered in the quiz and need a key
    val keyAnswers: Map<Int, Int> = emptyMap(),
    val errorMessage: String? = null
)

/**
 * Kotlin equivalent of `renderQuiz(true)` state + `finishKey()`.
 *
 * [numbersNeedingKey] mirrors `Object.keys(state.quizAnswers).map(Number)` —
 * only questions the user actually answered need a key; unanswered ones are
 * automatically "blank" and skip this screen entirely.
 */
class KeyViewModel(numbersNeedingKey: List<Int>) : ViewModel() {

    private val _state = MutableStateFlow(
        KeyUiState(numbers = numbersNeedingKey.sorted())
    )
    val state: StateFlow<KeyUiState> = _state.asStateFlow()

    /** Mirrors JS `choose(n, o, true)`: tapping the selected option again clears it. */
    fun choose(number: Int, option: Int) {
        _state.update { s ->
            val current = s.keyAnswers.toMutableMap()
            if (current[number] == option) current.remove(number) else current[number] = option
            s.copy(keyAnswers = current, errorMessage = null)
        }
    }

    /**
     * Mirrors `finishKey()`: validates every question has a key entered.
     * Returns true (and lets the caller proceed) only when complete;
     * otherwise sets [KeyUiState.errorMessage] and returns false.
     */
    fun tryFinish(): Boolean {
        val s = _state.value
        val missing = s.numbers.filter { s.keyAnswers[it] == null }
        if (missing.isNotEmpty()) {
            _state.update {
                it.copy(
                    errorMessage = "لطفاً کلید پاسخ همه تست‌ها را وارد کنید. " +
                        "${missing.size} تست بدون کلید باقی مانده است: ${missing.joinToString("، ")}"
                )
            }
            return false
        }
        return true
    }
}
