package com.example.quizapp.ui.nav

import com.example.quizapp.model.ReviewItem

/**
 * Transient handoff state for the browse-subject → review-quiz → review-key
 * → review-result mini-flow (mirrors the JS `state.reviewExam` scratch
 * object). Nothing here is `Parcelable`/`Serializable`, so — like every
 * other cross-screen "current selection" in this app — it's held in a
 * plain in-memory object instead of as Navigation-Compose route arguments.
 *
 * Limitation: this is lost on process death (not just configuration change),
 * since it isn't backed by `SavedStateHandle`. Acceptable for a short-lived
 * multi-step flow the user is actively in the middle of; worth revisiting
 * with `@Parcelize` + real nav args if that turns out to matter in practice.
 */
class ReviewSession {
    var pendingSubject: String? = null
    var pendingItems: List<ReviewItem>? = null
    var pendingQuizAnswers: Map<String, Int>? = null
    var pendingMissingItems: List<ReviewItem>? = null

    fun clear() {
        pendingSubject = null
        pendingItems = null
        pendingQuizAnswers = null
        pendingMissingItems = null
    }
}
