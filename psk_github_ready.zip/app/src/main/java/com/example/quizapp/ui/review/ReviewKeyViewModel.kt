package com.example.quizapp.ui.review

import androidx.lifecycle.ViewModel
import com.example.quizapp.model.ReviewItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class ReviewKeyUiState(
    val missingItems: List<ReviewItem> = emptyList(),
    val keyAnswers: Map<String, Int> = emptyMap(),
    val errorMessage: String? = null
)

/**
 * Kotlin/Compose equivalent of `renderReviewKey()` + `chooseReviewKey()` +
 * `finishReviewKey()`'s validation (the base-exam write-back itself lives in
 * `writeResolvedKeysBackToBaseExams()` since it needs the repository).
 */
class ReviewKeyViewModel(missingItems: List<ReviewItem>) : ViewModel() {

    private val _state = MutableStateFlow(ReviewKeyUiState(missingItems = missingItems.sortedBy { it.n }))
    val state: StateFlow<ReviewKeyUiState> = _state.asStateFlow()

    /** Mirrors `chooseReviewKey(itemKey,o)`. */
    fun choose(itemKey: String, option: Int) {
        _state.update { s ->
            val current = s.keyAnswers.toMutableMap()
            if (current[itemKey] == option) current.remove(itemKey) else current[itemKey] = option
            s.copy(keyAnswers = current, errorMessage = null)
        }
    }

    /** Mirrors `finishReviewKey()`'s validation: every missing item needs a key before continuing. */
    fun tryFinish(): Map<String, Int>? {
        val s = _state.value
        val unset = s.missingItems.filter { s.keyAnswers[it.itemKey] == null }
        if (unset.isNotEmpty()) {
            _state.update {
                it.copy(
                    errorMessage = "لطفاً کلید همه تست‌ها را وارد کنید. ${unset.size} تست بدون کلید باقی مانده است: " +
                        unset.joinToString("، ") { x -> x.n.toString() }
                )
            }
            return null
        }
        return s.keyAnswers
    }
}
