package com.example.quizapp.ui.review

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.quizapp.data.ExamRepository
import com.example.quizapp.model.Exam
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

data class ReviewTestsUiState(val subject: String = "", val exams: List<Exam> = emptyList())

/**
 * Kotlin/Compose equivalent of `openReviewTests()` + `renderReviewTests()` +
 * `saveEditReviewExam()` + `deleteReviewExam()`.
 */
class ReviewTestsListViewModel(
    private val repository: ExamRepository,
    private val subject: String
) : ViewModel() {

    val state: StateFlow<ReviewTestsUiState> = repository.exams
        .map { exams ->
            ReviewTestsUiState(
                subject = subject,
                exams = exams.filter { it.isReview && (it.subject ?: "") == subject }
                    .sortedByDescending { it.createdAt }
            )
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ReviewTestsUiState(subject = subject))

    /** Mirrors `saveEditReviewExam(id)`. */
    fun renameExam(id: String, newName: String) {
        repository.getExam(id)?.let { repository.updateExam(it.copy(reviewName = newName)) }
    }

    /** Mirrors `deleteReviewExam(id)`. */
    fun deleteExam(id: String) = repository.deleteExam(id)
}
