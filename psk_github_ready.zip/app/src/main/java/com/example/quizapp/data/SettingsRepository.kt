package com.example.quizapp.data

import android.content.Context
import android.content.SharedPreferences
import com.example.quizapp.ui.quiz.GroupSize
import com.example.quizapp.ui.quiz.SheetTheme
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Mirrors `loadSettings()`'s shape (`groupSize`/`theme`/`scoreCorrect`/`scoreWrongPenalty`/`streak`). */
data class AppSettings(
    val groupSize: GroupSize = GroupSize.FIVE,
    val theme: SheetTheme = SheetTheme.RED,
    val scoreCorrect: Int = 3,
    val scoreWrongPenalty: Int = 1,
    val streakCount: Int = 0,
    val streakLastDate: String? = null // yyyy-MM-dd, mirrors settings.streak.lastDate
)

interface SettingsRepository {
    val settings: StateFlow<AppSettings>

    /** Mirrors `setGroupSize(v)`. */
    fun setGroupSize(groupSize: GroupSize)

    /** Mirrors `setTheme(v)`. */
    fun setTheme(theme: SheetTheme)

    /** Mirrors `setScoreCoefficient(key,v)`'s validation (`Number.isFinite(n) && n>=0`). Returns false if invalid. */
    fun setScoreCoefficients(scoreCorrect: Int, scoreWrongPenalty: Int): Boolean

    /** Mirrors the streak-bump block that runs whenever an exam is finished. */
    fun recordCompletionForStreak()
}

/** SharedPreferences-backed implementation — same storage strategy as [PrefsExamRepository]. */
class PrefsSettingsRepository(context: Context) : SettingsRepository {

    private val prefs: SharedPreferences = context.getSharedPreferences("quiz_app_settings", Context.MODE_PRIVATE)
    private val _settings = MutableStateFlow(loadFromDisk())
    override val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private fun loadFromDisk(): AppSettings = AppSettings(
        groupSize = if (prefs.getInt(KEY_GROUP_SIZE, 5) == 10) GroupSize.TEN else GroupSize.FIVE,
        theme = when (prefs.getString(KEY_THEME, "red")) {
            "blue" -> SheetTheme.BLUE
            "green" -> SheetTheme.GREEN
            else -> SheetTheme.RED
        },
        scoreCorrect = prefs.getInt(KEY_SCORE_CORRECT, 3),
        scoreWrongPenalty = prefs.getInt(KEY_SCORE_WRONG, 1),
        streakCount = prefs.getInt(KEY_STREAK_COUNT, 0),
        streakLastDate = prefs.getString(KEY_STREAK_DATE, null)
    )

    private fun persist(s: AppSettings) {
        _settings.value = s
        prefs.edit()
            .putInt(KEY_GROUP_SIZE, s.groupSize.size)
            .putString(KEY_THEME, s.theme.name.lowercase(Locale.ROOT))
            .putInt(KEY_SCORE_CORRECT, s.scoreCorrect)
            .putInt(KEY_SCORE_WRONG, s.scoreWrongPenalty)
            .putInt(KEY_STREAK_COUNT, s.streakCount)
            .putString(KEY_STREAK_DATE, s.streakLastDate)
            .apply()
    }

    override fun setGroupSize(groupSize: GroupSize) = persist(_settings.value.copy(groupSize = groupSize))

    override fun setTheme(theme: SheetTheme) = persist(_settings.value.copy(theme = theme))

    override fun setScoreCoefficients(scoreCorrect: Int, scoreWrongPenalty: Int): Boolean {
        if (scoreCorrect < 0 || scoreWrongPenalty < 0) return false
        persist(_settings.value.copy(scoreCorrect = scoreCorrect, scoreWrongPenalty = scoreWrongPenalty))
        return true
    }

    override fun recordCompletionForStreak() {
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val today = fmt.format(Date())
        val s = _settings.value
        if (s.streakLastDate == today) return
        val yesterday = fmt.format(Date(System.currentTimeMillis() - 86_400_000L))
        val newCount = if (s.streakLastDate == yesterday) s.streakCount + 1 else 1
        persist(s.copy(streakCount = newCount, streakLastDate = today))
    }

    companion object {
        private const val KEY_GROUP_SIZE = "groupSize"
        private const val KEY_THEME = "theme"
        private const val KEY_SCORE_CORRECT = "scoreCorrect"
        private const val KEY_SCORE_WRONG = "scoreWrongPenalty"
        private const val KEY_STREAK_COUNT = "streakCount"
        private const val KEY_STREAK_DATE = "streakLastDate"
    }
}
