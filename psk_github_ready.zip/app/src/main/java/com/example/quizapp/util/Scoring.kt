package com.example.quizapp.util

import com.example.quizapp.data.ExamRepository
import com.example.quizapp.model.Exam
import com.example.quizapp.model.ExamResult

/**
 * Mirrors `settings.scoreCorrect` / `settings.scoreWrongPenalty` — the two
 * knobs the (not-yet-built) settings screen exposes for scoring. Defaults
 * match the JS fallbacks used in `calculateResult()`:
 * `Number(settings.scoreCorrect)||3` and `Number(settings.scoreWrongPenalty)??1`.
 */
data class ScoringSettings(
    val scoreCorrect: Int = 3,
    val scoreWrongPenalty: Int = 1
)

/**
 * Kotlin equivalent of the JS `calculateResult(e)`:
 * ```
 * function calculateResult(e){
 *   let all=e.numbers,a=e.quizAnswers||{},k=e.keyAnswers||{},correct=[],wrong=[],blank=[];
 *   all.forEach(n=>{if(a[n]){if(Number(a[n])===Number(k[n]))correct.push(n);else wrong.push(n)}else blank.push(n)});
 *   let sc=Number(settings.scoreCorrect)||3,sw=Number(settings.scoreWrongPenalty)??1;
 *   let percent=((correct.length*sc)-(wrong.length*sw))/(all.length*sc)*100;
 *   let elapsed=Number(e.elapsedTime??e.time??0)||0;
 *   return{correct,wrong,blank,correctCount:correct.length,wrongCount:wrong.length,blankCount:blank.length,percent,time:elapsed}
 * }
 * ```
 * A question counts as correct only when it was answered AND the answer
 * matches the key; unanswered questions are always "blank" regardless of
 * whether a key exists for them.
 */
fun calculateResult(exam: Exam, settings: ScoringSettings = ScoringSettings()): ExamResult {
    val all = exam.numbers
    val correct = mutableListOf<Int>()
    val wrong = mutableListOf<Int>()
    val blank = mutableListOf<Int>()

    all.forEach { n ->
        val userAnswer = exam.quizAnswers[n]
        if (userAnswer != null) {
            if (userAnswer == exam.keyAnswers[n]) correct.add(n) else wrong.add(n)
        } else {
            blank.add(n)
        }
    }

    val sc = if (settings.scoreCorrect != 0) settings.scoreCorrect else 3
    val sw = settings.scoreWrongPenalty
    val percent = if (all.isNotEmpty()) {
        ((correct.size * sc) - (wrong.size * sw)).toDouble() / (all.size * sc) * 100.0
    } else 0.0

    return ExamResult(
        correctCount = correct.size,
        wrongCount = wrong.size,
        blankCount = blank.size,
        percent = percent,
        correctNumbers = correct,
        wrongNumbers = wrong,
        blankNumbers = blank,
        timeSeconds = exam.elapsedTimeSeconds ?: 0L
    )
}

/**
 * Mirrors the recalculation loop inside `setScoreCoefficient()`:
 * `exams.forEach(e=>{if(!e.inProgress&&e.numbers?.length)e.result=calculateResult(e)})`.
 *
 * Deliberate fix vs. the original: that JS loop also touches review exams,
 * but `calculateResult()` reads `Int`-keyed `quizAnswers`/`keyAnswers` while
 * a review exam's answers are keyed by string `itemKey` — so in the JS
 * version this silently corrupts every review exam's result (everything
 * reads as "blank"). Review exams (`isReview`) are excluded here instead.
 */
fun recalculateAllExamResults(repository: ExamRepository, settings: ScoringSettings) {
    repository.exams.value.forEach { exam ->
        if (!exam.inProgress && !exam.isReview && exam.numbers.isNotEmpty()) {
            repository.updateExam(exam.copy(result = calculateResult(exam, settings)))
        }
    }
}
