package com.example.quizapp.ui.quiz

import androidx.compose.ui.graphics.Color

/** Mirrors `settings.groupSize` (5 or 10 questions per visual block). */
enum class GroupSize(val size: Int, val label: String) {
    FIVE(5, "۵ تایی"),
    TEN(10, "۱۰ تایی")
}

/**
 * Mirrors the CSS custom properties set per `.sheet-mode.theme-*` in the
 * original stylesheet:
 *   --sheet-border, --sheet-bg, --sheet-num-bg, --sheet-line,
 *   --sheet-num-color, --sheet-opt-border, --sheet-opt-color
 */
enum class SheetTheme(
    val label: String,
    val border: Color,
    val background: Color,
    val numberStripBg: Color,
    val groupDividerLine: Color,
    val numberColor: Color,
    val optionBorder: Color,
    val optionTextColor: Color
) {
    BLUE(
        label = "آبی ملایم",
        border = Color(0xFFB9CBE6),
        background = Color(0xFFF4F8FD),
        numberStripBg = Color(0xFFCFE1F6),
        groupDividerLine = Color(0xFFA3C0E6),
        numberColor = Color(0xFF0D1F3D),
        optionBorder = Color(0xFFA9C2E6),
        optionTextColor = Color(0xFF3A6BB8)
    ),
    RED(
        label = "قرمز ملایم",
        border = Color(0xFFE6B9B9),
        background = Color(0xFFFDF4F4),
        numberStripBg = Color(0xFFF6CFCF),
        groupDividerLine = Color(0xFFE6A3A3),
        numberColor = Color(0xFF3D0D0D),
        optionBorder = Color(0xFFE6A9A9),
        optionTextColor = Color(0xFFB83A3A)
    ),
    GREEN(
        label = "سبز ملایم",
        border = Color(0xFFB9E6C0),
        background = Color(0xFFF4FDF6),
        numberStripBg = Color(0xFFCFF6D6),
        groupDividerLine = Color(0xFFA3E6AB),
        numberColor = Color(0xFF0D3D17),
        optionBorder = Color(0xFFA9E6B0),
        optionTextColor = Color(0xFF3AB84F)
    )
}

/**
 * Font weight/size scale for the big question-number digits — mirrors the JS
 * `qNumWeight(n)` / `qNumSize(n)` helpers, which shrink the number slightly
 * as digit count grows so 4-digit numbers still fit the 48dp strip.
 */
fun qNumWeight(n: Int): Int {
    val len = kotlin.math.abs(n).toString().length
    return when {
        len >= 4 -> 635
        len == 3 -> 695
        len == 2 -> 750
        else -> 800
    }
}

fun qNumSizeSp(n: Int): Float {
    val len = kotlin.math.abs(n).toString().length
    return when {
        len >= 4 -> 19f
        len == 3 -> 19.5f
        len == 2 -> 19.6f
        else -> 20f
    }
}

/** Quiz-mode dark palette constants (from :root and .quiz-mode / .paper rules). */
object QuizPalette {
    val pageBackground = Color(0xFF080C11)   // --bg
    val paperBackground = Color(0xFF10161E)  // .quiz-mode background
    val paperBorder = Color(0xFF222C38)
    val titleColor = Color(0xFFF5F7FA)
    val subtitleColor = Color(0xFF8592A3)
    val countBadgeBg = Color(0xFF1B2531)
    val countBadgeText = Color(0xFFC7D2E0)
    val noticeBg = Color(0xFF182635)
    val noticeBorder = Color(0xFF2A4360)
    val noticeText = Color(0xFFA9C6E6)
    val primary = Color(0xFF4F8CFF)
    val primary2 = Color(0xFF3677EF)
    val btnSecondaryBg = Color(0xFF1B2531)
    val btnSecondaryText = Color(0xFFDBE4EE)
    val btnSaveLaterBg = Color(0xFF24344D)
    val btnSaveLaterText = Color(0xFFDBE7FF)
    val btnSaveLaterBorder = Color(0xFF3A506E)
    val timerBg = Color(0xFF151F2D)
    val timerBorder = Color(0xFF2E4055)
    val timerWarningBg = Color(0xFF8B2630)
    val optSelectedBg = Color(0xFF000000)
    val optSelectedText = Color(0xFFFFFFFF)
}
