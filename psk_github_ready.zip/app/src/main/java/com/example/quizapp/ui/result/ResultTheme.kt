package com.example.quizapp.ui.result

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** Mirrors the four `.result-filter-btn` tabs / `state.resultTab`. */
enum class ResultTab(val label: String) {
    ALL("همه تست‌ها"),
    CORRECT("تست‌های صحیح"),
    WRONG("تست‌های غلط"),
    BLANK("تست‌های نزده")
}

/** Mirrors JS `percentColor(p)`. */
enum class ResultBand { RED, YELLOW, GREEN, CYAN }

fun percentColor(percent: Double): ResultBand = when {
    percent <= 20 -> ResultBand.RED
    percent <= 50 -> ResultBand.YELLOW
    percent <= 79 -> ResultBand.GREEN
    else -> ResultBand.CYAN
}

/**
 * Colors lifted straight from the CSS custom properties used by the result
 * screen (`--bg`, `--surface`, `--surface2`, `--surface3`, `--line`,
 * `--text`, `--muted`, `--primary`, and the dark-mode `--correct-*` /
 * `--wrong-*` / `--blank-*` triplets).
 */
object ResultPalette {
    val pageBackground = Color(0xFF080C11) // --bg
    val panelBackground = Color(0xFF10161E) // --surface (.panel)
    val panelBorder = Color(0xFF263241) // --line
    val text = Color(0xFFF5F7FA) // --text
    val muted = Color(0xFF9AA8B8) // --muted
    val surface2 = Color(0xFF151D27) // --surface2 (.result-stat-item bg is surface3; ring inner is surface2)
    val surface3 = Color(0xFF1B2531) // --surface3 (.result-stat-item)
    val primary = Color(0xFF4F8CFF)

    // .result-ring conic-gradient stops
    val ringRed = Color(0xFFEF4444)
    val ringYellow = Color(0xFFEAB308)
    val ringGreen = Color(0xFF22C55E)
    val ringCyan = Color(0xFF14B8A6)
    val ringTrack = Color(0xFF222C38) // the "#222c38 0" remainder of the conic-gradient

    fun ringColor(band: ResultBand): Color = when (band) {
        ResultBand.RED -> ringRed
        ResultBand.YELLOW -> ringYellow
        ResultBand.GREEN -> ringGreen
        ResultBand.CYAN -> ringCyan
    }

    // --correct-1/--correct-2/--correct-border
    val correct1 = Color(0xFF0B4A28)
    val correct2 = Color(0xFF0D3B23)
    val correctBorder = Color(0xFF278252)

    // --wrong-1/--wrong-2/--wrong-border
    val wrong1 = Color(0xFF450A0A)
    val wrong2 = Color(0xFF38090D)
    val wrongBorder = Color(0xFF7F1D1D)

    // --blank-1/--blank-2/--blank-border
    val blank1 = Color(0xFF202E40)
    val blank2 = Color(0xFF192635)
    val blankBorder = Color(0xFF34485F)

    // .result-card.neutral gradient, used by the browse-list screen (not built yet)
    val neutral1 = Color(0xFF192636)
    val neutral2 = Color(0xFF14202D)
    val neutralBorder = Color(0xFF2C3E53)
}

/** `.result-card.<status>{background:linear-gradient(90deg,c1,c2)}` */
fun ResultPalette.cardGradient(status: ResultStatus): Brush = when (status) {
    ResultStatus.CORRECT -> Brush.horizontalGradient(listOf(correct1, correct2))
    ResultStatus.WRONG -> Brush.horizontalGradient(listOf(wrong1, wrong2))
    ResultStatus.BLANK -> Brush.horizontalGradient(listOf(blank1, blank2))
}

fun ResultPalette.cardBorder(status: ResultStatus): Color = when (status) {
    ResultStatus.CORRECT -> correctBorder
    ResultStatus.WRONG -> wrongBorder
    ResultStatus.BLANK -> blankBorder
}
