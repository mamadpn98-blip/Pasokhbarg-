package com.example.quizapp.util

import com.example.quizapp.model.Exam

/** One point on the percent-over-time chart — mirrors the `pts` array in `renderStats()`. */
data class StatsChartPoint(val index: Int, val percent: Double, val examId: String, val createdAt: Long, val tooltip: String)

/** One `.stats-subject-card` — mirrors the `subjects.map(...)` block when `statsSubject==='all'`. */
data class StatsSubjectSummary(val subject: String, val examCount: Int, val averagePercent: Double)

/** One `.stats-highlight-card` — mirrors the `card(label,e,val)` helper for a single subject's view. */
data class StatsHighlight(
    val label: String,
    val examId: String,
    val title: String,
    val value: String,
    val createdAt: Long,
    val questionCount: Int
)

data class StatsUiState(
    val subjects: List<String> = emptyList(),
    val selectedSubject: String? = null, // null == "همه درس‌ها" / JS 'all'
    val chartPoints: List<StatsChartPoint> = emptyList(),
    val averagePercent: Double? = null, // null when there are no exams to average
    val bestPercent: Double? = null,
    val totalQuestions: Int = 0,
    val totalCorrect: Int = 0,
    val subjectCards: List<StatsSubjectSummary> = emptyList(), // populated only when selectedSubject == null
    val highlights: List<StatsHighlight> = emptyList() // populated only when selectedSubject != null
)

/** Mirrors `statsData(subject='all')`. */
fun statsData(exams: List<Exam>, subject: String?): List<Exam> {
    val base = exams.filter { it.isBaseExam() }.sortedBy { it.createdAt }
    return if (subject == null) base else base.filter { (it.subject ?: "بدون نام") == subject }
}

/** Mirrors the body of `renderStats()`. */
fun buildStatsState(exams: List<Exam>, selectedSubject: String?): StatsUiState {
    val subjects = exams.filter { it.isBaseExam() }.map { it.subject ?: "بدون نام" }.distinct().sorted()
    val list = statsData(exams, selectedSubject)

    val averagePercent = if (list.isNotEmpty()) list.sumOf { it.result?.percent ?: 0.0 } / list.size else null
    val bestPercent = if (list.isNotEmpty()) list.maxOf { it.result?.percent ?: 0.0 } else null
    val totalCorrect = list.sumOf { it.result?.correctCount ?: 0 }
    val totalQuestions = list.sumOf { it.numbers.size }

    val chartPoints = list.mapIndexed { i, e ->
        StatsChartPoint(
            index = i,
            percent = (e.result?.percent ?: 0.0).coerceIn(0.0, 100.0),
            examId = e.id,
            createdAt = e.createdAt,
            tooltip = "${e.subject ?: "آزمون"} — ${"%.1f".format(e.result?.percent ?: 0.0)}٪"
        )
    }

    val subjectCards = if (selectedSubject == null) {
        subjects.map { sub ->
            val a = statsData(exams, sub)
            val p = if (a.isNotEmpty()) a.sumOf { it.result?.percent ?: 0.0 } / a.size else 0.0
            StatsSubjectSummary(sub, a.size, p)
        }
    } else emptyList()

    val highlights = if (selectedSubject != null && list.isNotEmpty()) {
        val fastest = list.minByOrNull { it.elapsedTimeSeconds ?: Long.MAX_VALUE }!!
        val slowest = list.maxByOrNull { it.elapsedTimeSeconds ?: 0L }!!
        val bestExam = list.maxByOrNull { it.result?.percent ?: 0.0 }!!
        val worstExam = list.minByOrNull { it.result?.percent ?: 0.0 }!!
        fun titleOf(e: Exam) = e.topic ?: e.source ?: "آزمون"
        listOf(
            StatsHighlight("🏆 بهترین آزمون", bestExam.id, titleOf(bestExam), "${"%.1f".format(bestExam.result?.percent ?: 0.0)}٪", bestExam.createdAt, bestExam.numbers.size),
            StatsHighlight("📉 بدترین آزمون", worstExam.id, titleOf(worstExam), "${"%.1f".format(worstExam.result?.percent ?: 0.0)}٪", worstExam.createdAt, worstExam.numbers.size),
            StatsHighlight("⚡ سریع‌ترین آزمون", fastest.id, titleOf(fastest), formatTime((fastest.elapsedTimeSeconds ?: 0L).toInt()), fastest.createdAt, fastest.numbers.size),
            StatsHighlight("🐢 کندترین آزمون", slowest.id, titleOf(slowest), formatTime((slowest.elapsedTimeSeconds ?: 0L).toInt()), slowest.createdAt, slowest.numbers.size)
        )
    } else emptyList()

    return StatsUiState(
        subjects = subjects,
        selectedSubject = selectedSubject,
        chartPoints = chartPoints,
        averagePercent = averagePercent,
        bestPercent = bestPercent,
        totalQuestions = totalQuestions,
        totalCorrect = totalCorrect,
        subjectCards = subjectCards,
        highlights = highlights
    )
}
