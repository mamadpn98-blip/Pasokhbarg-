package com.example.quizapp.ui.review

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.quizapp.model.Exam
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Kotlin/Compose equivalent of `renderReviewTests()` + `openEditReviewExam()`/
 * `saveEditReviewExam()` + `deleteReviewExam()`'s confirm+toast.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReviewTestsListScreen(
    viewModel: ReviewTestsListViewModel,
    onBack: () -> Unit,
    onOpenResult: (String) -> Unit
) {
    val state by viewModel.state.collectAsState()
    var editingExam by remember { mutableStateOf<Exam?>(null) }
    var pendingDelete by remember { mutableStateOf<Exam?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("آزمون‌های مرور — ${state.subject}") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "بازگشت") } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            Text(
                "آزمون‌های مرور این درس؛ درصد آن‌ها در آمار اصلی لحاظ نمی‌شود.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(16.dp)
            )
            if (state.exams.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("هنوز آزمون مروری برای این درس ساخته نشده است.")
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(state.exams) { index, exam ->
                        val label = exam.reviewName?.takeIf { it.isNotBlank() } ?: "آزمون مرور ${state.exams.size - index}"
                        ElevatedCard(onClick = { onOpenResult(exam.id) }, modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(label, fontWeight = FontWeight.Bold)
                                    Text(
                                        "${exam.items.size} تست · ${formatDate(exam.createdAt)}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                                Row {
                                    TextButton(onClick = { editingExam = exam }) { Text("✎") }
                                    TextButton(onClick = { pendingDelete = exam }) { Text("✕") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    editingExam?.let { exam ->
        RenameReviewExamDialog(
            initialName = exam.reviewName ?: "",
            onDismiss = { editingExam = null },
            onSave = { name -> viewModel.renameExam(exam.id, name); editingExam = null }
        )
    }

    pendingDelete?.let { exam ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("تأیید") },
            text = { Text("این آزمون مرور حذف شود؟") },
            confirmButton = {
                TextButton(onClick = { viewModel.deleteExam(exam.id); pendingDelete = null }) {
                    Text("حذف", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("انصراف") } }
        )
    }
}

@Composable
private fun RenameReviewExamDialog(initialName: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var name by remember { mutableStateOf(initialName) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ویرایش نام آزمون مرور") },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("نام آزمون مرور") },
                placeholder = { Text("مثلاً آزمون مرور اول") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = { TextButton(onClick = { onSave(name.trim()) }) { Text("💾 ذخیره") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

private fun formatDate(millis: Long): String =
    SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(Date(millis))
