package com.example.quizapp.ui.key

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.font.FontWeight
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Answer-key entry screen — Kotlin/Compose equivalent of `renderQuiz(true)` +
 * `.key-mode` CSS.
 *
 * Differences from [com.example.quizapp.ui.quiz.QuizScreen] that come
 * straight from the original CSS/JS (kept intentionally, not simplifications):
 *  - rows are plain dark rounded cards (`.key-mode .q-row`), NOT the colored
 *    number-strip sheet used on the quiz screen
 *  - the question number is plain light-gray text, not a big themed digit
 *  - options are laid out as a 4-column grid, not spaced full-width
 *  - digits are rendered as plain Arabic numerals here — the original JS
 *    calls `toPersianDigits()` on the quiz screen but NOT on this one
 *    (`${n}` / `${o}` used directly in `renderQuiz(true)`). Kept as-is for
 *    fidelity; flag it if you'd rather this screen use Persian digits too.
 *  - no timer chip, no "ذخیره و ادامه بعداً" button, button label is "اتمام"
 *  - always shows the "فقط تست‌های پاسخ‌داده‌شده..." notice
 */
@Composable
fun KeyScreen(
    viewModel: KeyViewModel,
    onFinish: (keyAnswers: Map<Int, Int>) -> Unit,
    onBack: () -> Unit
) {
    val state by viewModel.state.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(KeyPalette.pageBackground)
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 12.dp)) {
            // ---- topbar (no timer here) ----
            Text(
                "پاسخبرگ تستی",
                color = KeyPalette.titleColor,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                modifier = Modifier.height(48.dp).wrapContentHeight(Alignment.CenterVertically)
            )

            Spacer(Modifier.height(8.dp))

            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
                Column(
                    modifier = Modifier
                        .widthIn(max = 760.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(KeyPalette.paperBackground)
                        .border(1.dp, KeyPalette.paperBorder, RoundedCornerShape(24.dp))
                        .padding(20.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    // quiz-head
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "ورود کلید پاسخ",
                                color = KeyPalette.titleColor,
                                fontWeight = FontWeight.Black,
                                fontSize = 22.sp
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "برای هر تست، گزینه صحیح را وارد کنید.",
                                color = KeyPalette.subtitleColor,
                                fontSize = 13.sp
                            )
                        }
                        CountBadge(state.numbers.size)
                    }

                    Spacer(Modifier.height(12.dp))

                    // always shown in key mode
                    NoticeBox(
                        "توجه: فقط تست‌هایی که در پاسخ‌برگ برایشان گزینه‌ای زده‌اید در این لیست " +
                            "نمایش داده شده‌اند؛ تست‌های بدون پاسخ نیازی به کلید ندارند و به‌طور " +
                            "خودکار «نزده» محسوب می‌شوند."
                    )

                    Spacer(Modifier.height(12.dp))

                    if (state.numbers.isEmpty()) {
                        WarningOrEmptyNotice("هیچ تستی انتخاب نشده است؛ بنابراین تمام تست‌ها نزده محسوب خواهند شد.")
                    } else {
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                state.numbers.forEach { n ->
                                    KeyRow(
                                        number = n,
                                        selected = state.keyAnswers[n],
                                        onChoose = { o -> viewModel.choose(n, o) }
                                    )
                                }
                            }
                        }
                    }

                    state.errorMessage?.let { msg ->
                        Spacer(Modifier.height(14.dp))
                        WarningBox(msg)
                    }

                    Spacer(Modifier.height(24.dp))

                    Button(
                        onClick = { if (viewModel.tryFinish()) onFinish(state.keyAnswers) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = KeyPalette.primary)
                    ) { Text("اتمام", fontWeight = FontWeight.Bold) }

                    Spacer(Modifier.height(10.dp))

                    Button(
                        onClick = onBack,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = KeyPalette.btnSecondaryBg)
                    ) { Text("بازگشت به صفحه قبل", color = KeyPalette.btnSecondaryText, fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
}

@Composable
private fun CountBadge(count: Int) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(KeyPalette.countBadgeBg)
            .padding(horizontal = 11.dp, vertical = 7.dp)
    ) {
        Text("$count تست", color = KeyPalette.countBadgeText, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
private fun NoticeBox(text: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(KeyPalette.noticeBg)
            .border(1.dp, KeyPalette.noticeBorder, RoundedCornerShape(14.dp))
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Text(text, color = KeyPalette.noticeText, fontSize = 13.sp, lineHeight = 20.sp)
    }
}

@Composable
private fun WarningOrEmptyNotice(text: String) = NoticeBox(text)

@Composable
private fun WarningBox(text: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(KeyPalette.warningBg)
            .border(1.dp, KeyPalette.warningBorder, RoundedCornerShape(14.dp))
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Text(text, color = KeyPalette.warningText, fontSize = 13.sp, lineHeight = 20.sp)
    }
}

/**
 * A single plain row: `.key-mode .q-row` — 80dp number column + a 4-column
 * option grid, NOT the colored strip used on the quiz screen.
 */
@Composable
private fun KeyRow(
    number: Int,
    selected: Int?,
    onChoose: (Int) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(KeyPalette.rowBackground)
            .border(1.dp, KeyPalette.rowBorder, RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(modifier = Modifier.width(80.dp), contentAlignment = Alignment.Center) {
            // NOTE: plain digits here, matching the original renderQuiz(true) — see file header.
            Text(
                number.toString(),
                color = KeyPalette.numberColor,
                fontWeight = FontWeight.Black,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
        Row(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            (1..4).forEach { option ->
                KeyOptionButton(
                    option = option,
                    isSelected = selected == option,
                    modifier = Modifier.weight(1f),
                    onClick = { onChoose(option) }
                )
            }
        }
    }
}

@Composable
private fun KeyOptionButton(
    option: Int,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val bg = if (isSelected) KeyPalette.optSelectedBg else Color(0xFFF8FAFC)
    val textColor = if (isSelected) KeyPalette.optSelectedText else Color(0xFF334155)
    val borderColor = if (isSelected) KeyPalette.optSelectedBg else Color(0xFFCBD5E1)

    Box(
        modifier = modifier
            .heightIn(min = 44.dp)
            .clip(RoundedCornerShape(13.dp))
            .background(bg)
            .border(1.dp, borderColor, RoundedCornerShape(13.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        // NOTE: plain digits here too, matching the original.
        Text(option.toString(), color = textColor, fontWeight = FontWeight.Black)
    }
}

private object KeyPalette {
    val pageBackground = Color(0xFF080C11)
    val paperBackground = Color(0xFF10161E)
    val paperBorder = Color(0xFF222C38)
    val titleColor = Color(0xFFF5F7FA)
    val subtitleColor = Color(0xFF8592A3)
    val countBadgeBg = Color(0xFF1B2531)
    val countBadgeText = Color(0xFFC7D2E0)
    val noticeBg = Color(0xFF182635)
    val noticeBorder = Color(0xFF2A4360)
    val noticeText = Color(0xFFA9C6E6)
    val warningBg = Color(0xFF2A2415)
    val warningBorder = Color(0xFF4A3F1C)
    val warningText = Color(0xFFE8D38A)
    val primary = Color(0xFF4F8CFF)
    val btnSecondaryBg = Color(0xFF1B2531)
    val btnSecondaryText = Color(0xFFDBE4EE)
    val rowBackground = Color(0xFF151B24)
    val rowBorder = Color(0xFF222C38)
    val numberColor = Color(0xFFE7ECF2)
    val optSelectedBg = Color(0xFF000000)
    val optSelectedText = Color(0xFFFFFFFF)
}
