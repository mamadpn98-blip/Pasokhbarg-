# تبدیل به Kotlin / Jetpack Compose

## صفحهٔ خانه (Home)
- `model/Exam.kt` — معادل کاتلینی آبجکت exam در JS.
- `data/ExamRepository.kt` — جایگزین `localStorage` (SharedPreferences+Gson).
- `ui/home/HomeViewModel.kt` — معادل `getFilteredExams()` با فیلتر `isReview`
  از همون اول اعمال‌شده (رفع باگ قبلی).
- `ui/home/HomeScreen.kt` — کارت آمار، جست‌وجو/مرتب‌سازی، گرید آزمون‌ها،
  حذف/ویرایش با نگه‌داشتن، FAB.

## صفحهٔ پاسخبرگ (Quiz answer sheet)
- `ui/quiz/QuizTheme.kt` — پالت رنگی سه تم (آبی/قرمز/سبز) دقیقاً برابر با
  متغیرهای CSS اصلی (`--sheet-*`)، به‌علاوهٔ اندازه/وزن فونت شمارهٔ تست
  (معادل `qNumWeight`/`qNumSize`) و پالت حالت تاریک صفحه (`QuizPalette`).
- `ui/quiz/QuizViewModel.kt` — نگه‌داری شماره‌ی تست‌ها، پاسخ‌ها، گروه‌بندی
  ۵/۱۰تایی، تم، و تایمر شمارش‌معکوس (معادل `choose()` / `startTimer()`).
- `ui/quiz/QuizScreen.kt` — پیاده‌سازی کامل رابط:
  - کارت «کاغذی» تیره با گوشه‌های گرد، دقیقاً مثل `.paper.quiz-mode`
  - نشان تعداد تست (count-badge)
  - ورقهٔ پاسخ‌برگ با نوار رنگیِ شماره در هر ردیف، خط جداکنندهٔ بین گروه‌های
    ۵/۱۰تایی، و چهار گزینهٔ هر تست به ترتیب چپ‌به‌راست (جهت LTR اجباری،
    دقیقاً مثل نسخهٔ اصلی)
  - گزینهٔ انتخاب‌شده = پس‌زمینهٔ مشکی/متن سفید
  - تایمر شناور بالا-چپ با حالت هشدار (رنگ قرمز) در ۶۰ ثانیهٔ پایانی
  - دکمه‌های «ادامه»، «ذخیره و ادامه بعداً»، «بازگشت به صفحه قبل»
- `util/Formatting.kt` — `toPersianDigits()` و `formatTime()`.

## صفحهٔ ورود کلید پاسخ (Key entry)
- `ui/key/KeyViewModel.kt` — نگه‌داری پاسخ‌های کلید و اعتبارسنجی هنگام اتمام
  (معادل `finishKey()`؛ اگر تستی بدون کلید بمونه، پیام خطا نشون داده می‌شه).
- `ui/key/KeyScreen.kt` — پیاده‌سازی کامل رابط، **با تفاوت‌های عمدی نسبت به
  صفحهٔ پاسخبرگ که در خودِ کد اصلی هم همینطوره**:
  - ردیف‌ها ساده و تیره‌ان (`.key-mode .q-row`)، نه نوار رنگیِ شماره
  - شمارهٔ تست فقط متن ساده‌ی خاکستری روشنه، نه رقم بزرگ رنگی
  - گزینه‌ها به‌صورت گرید ۴ستونه چیده شدن (نه پخش تمام‌عرض مثل پاسخبرگ)
  - **ارقام همون اعداد انگلیسی معمولی نمایش داده می‌شن، نه فارسی** — چون
    کد اصلی در `renderQuiz(true)` از `toPersianDigits()` استفاده نکرده
    (برخلاف صفحهٔ پاسخبرگ که استفاده کرده). این رو عمداً همینطوری نگه
    داشتم برای مطابقت کامل؛ اگه فکر می‌کنی این یه ناهماهنگی/باگ کوچیکه و
    می‌خوای اینجا هم فارسی بشه بگو تا درستش کنم.
  - بدون تایمر، بدون دکمهٔ «ذخیره و ادامه بعداً»، دکمهٔ اصلی «اتمام»
  - نوار هشدار (notice) همیشه نمایش داده می‌شه؛ در صورت ناقص بودن کلیدها
    هنگام زدن «اتمام»، جعبهٔ هشدار زرد/کهربایی با لیست شماره‌های ناقص
    نمایش داده می‌شه (معادل `.warning`)

## صفحهٔ ساخت آزمون (Setup wizard)
- `ui/setup/SetupViewModel.kt` — معادل `state.wizardData` + `wizardNext()` +
  `startQuiz()`: سه مرحله (مشخصات آزمون، بازه تست‌ها، نوع تست‌ها)، همون
  قوانین اعتبارسنجی خط‌به‌خط (نام درس اجباری، زمان آزمون حداقل ۱ دقیقه و
  عدد صحیح، بازهٔ سوال حداکثر ۲۰۱ تست، شروع نمی‌تواند صفر باشد، پایان باید
  بزرگ‌تر یا مساوی شروع باشد)، و شمارندهٔ زندهٔ تعداد تست‌ها روی مرحلهٔ دوم.
- `ui/setup/SetupScreen.kt` — پیاده‌سازی کامل رابط: نوار پیشرفت سه‌مرحله‌ای
  (نقطه‌های `done`/`active`)، فرم هر مرحله، جعبهٔ خطا (`.error`)، جعبهٔ
  اطلاع (`.notice`)، تراشهٔ شمارندهٔ زنده (`.live-count`)، و دکمه‌های
  «مرحله بعد/تأیید و ادامه» + «مرحله قبل/انصراف».
  **یک مورد که عمداً ساده‌سازی شده:** فیلدهای نام درس/مبحث/منبع در نسخهٔ
  اصلی read-only هستن و با تپ کردن یه پنل پیشنهاد (autocomplete) از
  آزمون‌های قبلی باز می‌کنن (`.autocomplete-field` / `.suggest-panel`).
  اینجا فعلاً فیلد متنی سادهٔ قابل‌ویرایشه — اگه می‌خوای اون پنل پیشنهاد
  رو هم دقیق بسازم بگو (نیاز به وصل‌شدن به لیست تاریخچهٔ آزمون‌ها داره).

## صفحهٔ نتیجه (Result) — تازه اضافه شد
- `util/Scoring.kt` — `ScoringSettings` (معادل `settings.scoreCorrect` /
  `settings.scoreWrongPenalty`، با مقادیر پیش‌فرض ۳ و ۱ دقیقاً مثل کد اصلی)
  و `calculateResult()` — معادل کامل تابع JS `calculateResult(e)`: هر تست
  فقط وقتی «صحیح» حساب می‌شه که هم پاسخ داده شده باشه هم با کلید یکی باشه؛
  در غیر این صورت یا «غلط»‌ه (پاسخ داده ولی نادرست) یا «نزده» (اصلاً
  پاسخ داده نشده). فرمول درصد هم عیناً همون
  `((correct*sc)-(wrong*sw))/(all.length*sc)*100`.
- `model/Exam.kt` — به `ExamResult` فیلدهای `correctNumbers`/`wrongNumbers`/
  `blankNumbers`/`timeSeconds` اضافه شد (برای فیلتر تب‌ها و نمایش زمان)،
  و به `Exam` فیلدهای `timed`/`durationMinutes` اضافه شد (این دو از قبل
  توسط ویزارد ساخت آزمون تولید می‌شدن ولی جایی برای ذخیره‌شدن روی خودِ
  آزمون نداشتن — بدون این‌ها صفحهٔ نتیجه نمی‌تونست «از X دقیقه» رو برای
  آزمون‌های زمان‌دار نشون بده).
- `ui/result/ResultViewModel.kt` — معادل `renderResult()` + `resultContent()`
  + `resultItem()` + `setResultTab()`. اگه `exam.result` از قبل محاسبه نشده
  باشه (`e.result||calculateResult(e)`)، همینجا محاسبه می‌شه.
- `ui/result/ResultTheme.kt` — `percentColor()` (نگاشت درصد به یکی از
  چهار رنگ قرمز/زرد/سبز/فیروزه‌ای، دقیقاً با آستانه‌های ≤20/≤50/≤79/بیشتر)
  و پالت رنگی کامل بر اساس متغیرهای CSS اصلی (`--correct-*`/`--wrong-*`/
  `--blank-*`/`--surface2`/`--surface3`/...).
- `ui/result/ResultScreen.kt` — پیاده‌سازی کامل رابط:
  - نوار بالا فقط عنوان «نتیجه آزمون» بدون دکمه بازگشت (دقیقاً مثل نسخهٔ
    اصلی؛ تنها راه خروج دکمهٔ «بازگشت به صفحه اصلی» پایین صفحه‌ست)
  - حلقهٔ درصد (donut chart) با `Canvas` — معادل `conic-gradient` +
    `.result-ring-inner`، رنگش بر اساس `percentColor`
  - نمایش زمان پاسخ‌گویی، و برای آزمون‌های زمان‌دار "از X" کنارش
  - گرید ۴تایی آمار (همه/صحیح/غلط/نزده)
  - چهار تب فیلتر (`ResultFilterRow`، جهت اجباری LTR مثل خود CSS)
  - لیست کارت‌های نتیجه با گرادیان رنگی صحیح/غلط/نزده بر اساس متغیرهای
    اصلی CSS، نمایش «جواب شما» / «گزینه صحیح»
  - افکت کنفتی (`ConfettiOverlay`) وقتی درصد ≥۸۰ باشه — معادل سبک‌شدهٔ
    `fireConfetti()`: حدود ۹۰ تکه که حدود ۳ ثانیه با چرخش و افت تصادفی
    می‌ریزن پایین و بعد خودشون حذف می‌شن

## صفحهٔ خانه (Home) — تکمیل شد
- `ui/home/HomeViewModel.kt` — سه متد اضافه شد: `updateExamDetails()` (معادل
  `saveEditExam()`)، `restoreExam()` (معادل شاخهٔ Undo داخل `deleteExam()`؛
  با یه ساده‌سازی عمدی: به‌جای برگردوندن به ایندکس دقیق قبلی، آزمون به
  بالای لیست برمی‌گرده — چون لیست پیش‌فرض بر اساس تاریخ نزولی مرتبه، این
  عملاً تقریباً همیشه با رفتار اصلی یکیه).
- `ui/home/HomeScreen.kt`:
  - **منوی کشویی (drawer)** با `ModalNavigationDrawer` — معادل `openDrawer()`؛
    سه آیتم مرور تست‌ها/آمار/تنظیمات، با کال‌بک‌های ناوبری
    (`onNavigateToBrowse`/`onNavigateToStats`/`onNavigateToSettings`) چون
    خود اون صفحات هنوز ساخته نشدن.
  - **مودال ویرایش آزمون** (`EditExamDialog`) — معادل `openEditExam()`/
    `saveEditExam()`، با همون اعتبارسنجی (نام آزمون نمی‌تواند خالی باشد).
  - **تأیید حذف + Undo** (`ConfirmDialog` + `SnackbarHostState`) — معادل
    `showConfirm()` + `showUndoToast()`. به‌جای پیاده‌سازی دستیِ toast،
    از Snackbar استاندارد Compose استفاده شد (مدت‌زمان ~۴ث به‌جای ۵۰۰۰ میلی‌ثانیهٔ
    دقیق نسخهٔ اصلی — تفاوت جزئیه و به‌خاطر سادگی پذیرفته شد).
  - این‌ها (درور/دیالوگ‌ها) عمداً با کامپوننت‌های استاندارد Material3
    (`ModalNavigationDrawer`/`AlertDialog`/`SnackbarHost`) ساخته شدن نه
    کپی پیکسل‌به‌پیکسلِ CSS، برخلاف Quiz/Key/Result — چون خودِ Home از
    اول همین سبک idiomatic Material3 رو داشت (نه پالت رنگی دستی).

## مرور تست‌ها + آزمون‌های مرور (Browse & Review) — تازه اضافه شد
- `model/Exam.kt` از قبل (بین این پیام و پیام قبلی) `ReviewItem`/`ReviewResult`
  و فیلدهای `reviewName`/`items`/`reviewResults`/`reviewQuizAnswers` و متد
  کمکی `isBaseExam()` رو روی `Exam` داشت — دقیقاً همون معماری JS که
  آزمون‌های مرور رو توی همون آرایهٔ `exams` نگه می‌داره (با پرچم
  `isReview`)، نه یه استور جدا. کدهای زیر از همینا استفاده می‌کنن.
- `util/Browse.kt` — معادل خالص `itemIdentity()`/`calcResultOf()`/
  `getBrowseSubjects()`/`getSubjectItems()` (شامل نشونهٔ ★ برای تستی که
  توی یه آزمون مرور دوباره غلط زده شده). ساده‌سازی عمدی: مرتب‌سازی
  دروس با `sortedBy` لغوی ساده، نه Collator فارسی.
- `util/ReviewScoring.kt` — معادل خالص `finishReviewQuiz()`/
  `finishReviewKey()`: نمره‌گذاری آیتم‌های مرور، و نوشتن کلید تازه‌واردشده
  برای تست‌های نزده به‌عقب روی خودِ آزمون اصلی (`baseExam.keyAnswers`/
  `baseExam.result` آپدیت می‌شن، دقیقاً مثل نسخهٔ اصلی).
- `ui/browse/BrowseListViewModel.kt` + `BrowseListScreen.kt` — معادل
  `goBrowseList()`/`renderBrowseList()`: کارت هر درس با تعداد تست، و
  دکمهٔ 📝 برای بازکردن آزمون‌های مرور همون درس.
- `ui/browse/BrowseSubjectViewModel.kt` + `BrowseSubjectScreen.kt` —
  معادل `renderBrowseSubject()` + `setBrowseTab()` + فیلتر/ترتیب +
  حالت انتخاب برای ساخت آزمون مرور (`startReviewSelection`/
  `toggleReviewItem`/`toggleSelectAllBrowse`/`createReviewQuiz`).
  ساده‌سازی: مودال فیلتر/ترتیب با `AlertDialog` + `RadioButton` ساخته
  شده، نه کنترل سگمنتی سفارشی CSS.
- `ui/review/ReviewQuizViewModel.kt` + `ReviewQuizScreen.kt` — معادل
  `renderReviewQuiz()`/`chooseReviewAnswer()`؛ همون ظاهر پاسخ‌برگ رنگی
  Quiz (از `QuizPalette`/`SheetTheme` عمومی استفاده مجدد شده) ولی
  ردیف‌ها با `itemKey` (رشته) شناسایی می‌شن نه شماره تست، و بدون تایمر.
- `ui/review/ReviewKeyViewModel.kt` + `ReviewKeyScreen.kt` — معادل
  `renderReviewKey()`/`chooseReviewKey()`/اعتبارسنجی `finishReviewKey()`؛
  فقط برای تست‌هایی که توی آزمون اصلی نزده بودن و کلید ندارن.
- `ui/review/ReviewResultScreen.kt` — معادل `renderReviewResult()`،
  با استفاده مجدد از `ResultPalette` (رنگ کارت‌های صحیح/غلط/نزده).
  ستون چهارم آمار («درصد آماری») عمداً همیشه «—»ه، چون آزمون مرور
  اصلاً درصد نداره (از آمار کلی هم مستثناست).
- `ui/review/ReviewTestsListViewModel.kt` + `ReviewTestsListScreen.kt` —
  معادل `renderReviewTests()` + ویرایش نام (`openEditReviewExam`) + حذف
  با تأیید (`deleteReviewExam`).
- **نکتهٔ اتصال:** این‌ها هم مثل بقیهٔ صفحات این پروژه از طریق کال‌بک
  به هم وصل می‌شن، نه NavHost. مسیر معمول: `BrowseListScreen`
  (`onOpenSubject`) → `BrowseSubjectScreen` (`onStartReviewQuiz` با
  لیست `ReviewItem`های انتخاب‌شده) → `ReviewQuizScreen` (اگه
  `itemsMissingKey()` خالی نبود برو `ReviewKeyScreen`، وگرنه مستقیم
  `finishReviewExam()` از `util/ReviewScoring.kt` رو صدا بزن) →
  ذخیره با `repository.addExam(...)` → `ReviewResultScreen`.

## آمار (Stats) — تازه اضافه شد
- `util/Stats.kt` — معادل خالص `statsData()`/بدنهٔ `renderStats()`: میانگین/
  بهترین درصد، جمع تست‌ها و پاسخ‌های صحیح، نقاط نمودار (`StatsChartPoint`)،
  کارت هر درس (وقتی «همه درس‌ها» انتخابه)، و ۴ کارت رکورد بهترین/بدترین/
  سریع‌ترین/کندترین آزمون (وقتی یه درس خاص انتخاب شده).
- `ui/stats/StatsViewModel.kt` — معادل `goStats()` + `state.statsSubject`.
- `ui/stats/StatsScreen.kt` — نمودار خط روند درصد با `Canvas` دست‌ساز
  (خطوط شبکه هر ۱۰٪ + برچسب درصد + پلی‌لاین + نقطه هر آزمون)، معادل
  دقیق SVG اصلی. زیرش کارت‌های KPI و بسته به انتخاب درس، یا گرید کارت‌های
  درس یا ۴ کارت رکورد (با تپ رفتن به `ReviewResultScreen`/`ResultScreen`
  از طریق `onOpenResult`).

## تنظیمات (Settings) — تازه اضافه شد
- `data/SettingsRepository.kt` — معادل `loadSettings()`/`saveSettings()`
  با SharedPreferences (همون استراتژی `PrefsExamRepository`). `AppSettings`
  شامل `groupSize`/`theme` (با enumهای عمومی `GroupSize`/`SheetTheme` از
  `ui.quiz` — نه رشته/عدد خام) و `scoreCorrect`/`scoreWrongPenalty`/استریک.
- `util/Scoring.kt` یه تابع جدید گرفت: `recalculateAllExamResults()` —
  معادل حلقهٔ بازمحاسبهٔ نتیجهٔ همهٔ آزمون‌ها در `setScoreCoefficient()`.
  **یه تفاوت عمدی نسبت به نسخهٔ اصلی**: نسخهٔ JS این حلقه رو روی آزمون‌های
  مرور هم اجرا می‌کنه، ولی چون `calculateResult()` با `quizAnswers`ی که با
  عدد Key شدن کار می‌کنه و پاسخ‌های آزمون مرور با رشتهٔ `itemKey` Key
  شدن، این عملاً نتیجهٔ هر آزمون مرور رو خراب می‌کنه (همه‌چی «نزده» حساب
  می‌شه) — یه باگ در نسخهٔ اصلی. اینجا آزمون‌های مرور از این بازمحاسبه
  عمداً مستثنا شدن.
- `data/ExamRepository.kt` دو متد جدید گرفت: `exportBackupJson()` و
  `importBackupJson()` — معادل خالص `backupToFile()`/`restoreFromFile()`
  (شامل پارس هم‌فرمت آرایهٔ خام و هم `{exams:[...]}`، و جایگزینی کامل
  لیست نه merge).
- `ui/settings/SettingsViewModel.kt` + `SettingsScreen.kt` — معادل
  `renderSettings()`. انتخاب‌گرهای تقسیم‌بندی/تم با `FilterChip` ساخته
  شدن (نه رادیوی سگمنتی CSS). دیالوگ تأیید جایگزینی بک‌آپ
  (`⚠️ آیا اطلاعات فعلی جایگزین شود؟`) کامل پیاده‌سازی شده.
  **محدودیت مهم:** خودِ خواندن/نوشتن فایل (Storage Access Framework) نیاز
  به `Activity` داره که این پروژه اصلاً نداره؛ `onExportBackup`/
  `onPickImportFile` دو قلاب (hook) هستن که یه `MainActivity` آینده باید
  بهشون وصل بشه (به کامنت‌های بالای `SettingsScreen.kt` نگاه کنید).
- **نکتهٔ اتصال:** `ResultViewModel`/`ReviewKeyViewModel` (و هر جای دیگه که
  `ScoringSettings()` پیش‌فرض می‌گیره) باید از این به بعد
  `ScoringSettings(settings.value.scoreCorrect, settings.value.scoreWrongPenalty)`
  رو از `SettingsRepository` بگیرن، نه مقدار پیش‌فرض ۳/۱.

## اتوکامپلیت فیلدهای درس/مبحث/منبع — تازه اضافه شد
- `ui/setup/SetupViewModel.kt` حالا `pastExams: List<Exam>` می‌گیره و
  معادل `buildSuggestCache()`/`freqValues()`/`filterSuggestions()` رو
  به‌صورت متد خالص `suggestionsFor(field, query)` داره (فیلتر
  case-insensitive روی زیررشته، سقف ۸ نتیجه، مرتب بر اساس بیشترین تکرار
  در آزمون‌های قبلی).
- `ui/setup/SetupScreen.kt`: فیلدهای نام درس/مبحث/منبع حالا
  `LabeledAutocompleteField` هستن — با `ExposedDropdownMenuBox` استاندارد
  Material3 به‌جای الگوی readonly/editable-toggle + پنل انیمیشنی CSS
  نسخهٔ اصلی. تپ یا تایپ لیست فیلترشده رو نشون می‌ده، تپ روی یه گزینه
  پرش می‌کنه. یه ساده‌سازی آگاهانه: «فقط یه پنل هم‌زمان باز باشه»
  (`closeOtherSuggestFields`) دیگه دستی مدیریت نمی‌شه — رفتار پیش‌فرض
  Compose برای بستن با کلیک بیرون از دراپ‌داون همین اثر رو عملاً می‌ده.
- `MainActivity.kt`: مسیر `setup` حالا `container.examRepository.exams.value`
  رو به `SetupViewModel` پاس می‌ده.

## اتصال نهایی (MainActivity / NavHost / build.gradle) — تازه اضافه شد
حالا پروژه از نظر ساختاری قابل build شدنه (با محدودیت‌های زیر). فایل‌های جدید:

- `settings.gradle.kts` + `build.gradle.kts` (ریشه) + `gradle.properties` +
  `app/build.gradle.kts` — پیکربندی استاندارد یک اپ Compose تک‌ماژولی
  (AGP 8.7.2 / Kotlin 2.0.21 / compileSdk 35 / minSdk 26).
- `app/src/main/AndroidManifest.xml` + `res/values/strings.xml` +
  `res/values/themes.xml` — حداقلی؛ آیکون لانچر سفارشی نداره (از آیکون
  پیش‌فرض سیستم استفاده می‌شه).
- `data/AppContainer.kt` — کل DI این پروژه؛ فقط دو ریپازیتوری رو نگه
  می‌داره و در `MainActivity.onCreate` یک‌بار ساخته می‌شه.
- `ui/nav/ReviewSession.kt` — نگه‌دارندهٔ موقت داده‌های بین‌صفحه‌ای برای
  زنجیرهٔ browse→review-quiz→review-key→review-result (چون `ReviewItem`
  نه `Parcelable`ه نه به شکل آرگومان مسیر Navigation Compose قابل‌انتقاله).
  محدودیت مستندشده: با از بین رفتن پردازش (نه فقط چرخش صفحه) این داده از
  دست می‌ره.
- `MainActivity.kt` — `NavHost` با ۱۳ مسیر، معادل کاملِ سوییچ
  `state.page` در JS. همهٔ ViewModelها این‌جا با `viewModelFactory` ساخته
  می‌شن (هیچ‌کدوم constructor بدون آرگومان ندارن). پشتیبان‌گیری/بازیابی
  از طریق SAF واقعی (`ActivityResultContracts.CreateDocument`/
  `OpenDocument`) وصل شده.

**تغییرات کوچک در فایل‌های قبلی برای اتصال واقعی:**
- `ui/quiz/QuizViewModel.kt` دو پارامتر گرفت: `existingAnswers` (برای
  ازسرگیری آزمون نیمه‌کاره) و `initialElapsedSeconds`، به‌علاوه یه
  استاپ‌واچ داخلی برای آزمون‌های بدون‌تایمر (`elapsedSecondsForSave()`) —
  بدون این‌ها ذخیرهٔ `Exam.elapsedTimeSeconds` واقعی ممکن نبود.

## ساخت APK از طریق GitHub Actions

1. محتویات این پروژه را در یک repository گیت‌هاب آپلود کنید (پوشهٔ `.github` هم باید آپلود شود).
2. از تب **Actions**، workflow با نام **Build Android APK** را انتخاب کنید و در صورت نیاز **Run workflow** را بزنید. با هر push یا pull request هم به‌طور خودکار اجرا می‌شود.
3. پس از سبز شدن اجرا، در بخش **Artifacts** فایل `quizapp-debug-apk` را دانلود و ZIP آن را باز کنید؛ فایل داخل آن `app-debug.apk` است.

این خروجی نسخهٔ **debug** برای نصب و آزمایش است. ساخت APK واقعی در این محیط اجرا نشده؛ نتیجه فقط پس از موفقیت workflow در GitHub تأیید می‌شود. برای انتشار عمومی/فروشگاه، باید نسخهٔ release را با کلید امضای اختصاصی امضا کنید.

## محدودیت‌های شناخته‌شده
- **ساخت واقعی هنوز تأیید نشده:** نسخه‌های AGP 8.7.2، Kotlin 2.1.21 و
  Gradle 8.12.1 با توجه به ماتریس سازگاری انتخاب شده‌اند؛ با این حال، تا زمانی
  که workflow در GitHub اجرا و سبز نشود، نمی‌توان موفقیت کامپایل را قطعی دانست.
- **گردلی wrapper کامل نیست:** `gradle/wrapper/gradle-wrapper.properties`
  هست ولی `gradlew`/`gradlew.bat`/`gradle-wrapper.jar` داخل نسخهٔ اولیه نبودند.
  workflow گیت‌هاب در `.github/workflows/build-apk.yml` این کمبود را دور می‌زند:
  Gradle 8.12.1 را روی runner نصب می‌کند و با دستور `gradle :app:assembleDebug`
  نسخهٔ debug را می‌سازد. برای build محلی می‌توانید پروژه را در Android Studio
  باز کنید یا پس از نصب Gradle، دستور `gradle wrapper` را اجرا کنید.
- **پشتیبان‌گیری واقعاً تست نشده** (بدون دستگاه/شبیه‌ساز، فقط کد کامپایل‌پذیر
  نوشته شده — منطق export/import (`ExamRepository`) جدا تست‌پذیره).
- **بدون تست خودکار:** نه واحد، نه UI — چیزی که این تبدیل هیچ‌وقت نداشت.

## وابستگی‌های استفاده‌شده (در `app/build.gradle.kts`)
```
androidx.compose:compose-bom:2024.10.01
androidx.compose.ui:ui / ui-graphics / ui-tooling-preview
androidx.compose.material3:material3
androidx.compose.material:material-icons-extended
androidx.activity:activity-compose:1.9.3
androidx.lifecycle:lifecycle-runtime-ktx / lifecycle-viewmodel-ktx / lifecycle-viewmodel-compose:2.8.7
androidx.navigation:navigation-compose:2.8.4
com.google.code.gson:gson:2.11.0
```
