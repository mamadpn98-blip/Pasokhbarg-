// Top-level build file — plugin *versions* are declared here (and applied
// per-module with `apply false`), matching current Android Gradle Plugin
// convention. Bump these via Android Studio's "Upgrade Assistant" — pinned
// here to versions that were current as of this project's last edit, but
// this file was written without network access to verify against the very
// latest releases, so treat them as a reasonable starting point rather than
// a verified-current pin.
plugins {
    id("com.android.application") version "8.7.2" apply false
    id("org.jetbrains.kotlin.android") version "2.1.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.1.21" apply false
}
